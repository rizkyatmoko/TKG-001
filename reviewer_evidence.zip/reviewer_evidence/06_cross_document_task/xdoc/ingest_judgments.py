"""Validate chatbot respondsTo judgments and emit cross-document edges.

Every check here exists because something in this project failed silently once.
Collapsed event ids passed validation vacuously because source and target joined
on the same collapsed keys; a clean ingest report certified 22% of a corpus
because the only check available needed an event to fire on. So:

  * the validator is exercised by `--self-test`, which feeds one deliberately
    corrupt input per check and asserts that exact code fires, then feeds a clean
    input and asserts zero problems AND a non-zero number of assertions made.
    A check that cannot fail its own test is not a check.
  * `checks_made` is reported alongside `problems`. "0 problems" is only
    meaningful next to how many things were actually examined.

Judgment ids are matched against `judge-index.json` by exact set membership, not
by position or suffix, so a renumbered or reordered reply cannot silently join.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).parent
BASIS = {"explicit", "same_incident", "thematic", "none"}
POSITIVE_BASIS = {"explicit", "same_incident"}


def strip_fences(text: str) -> str:
    """Chatbots wrap JSON in prose and fences; the reply is saved verbatim."""
    m = re.search(r"```(?:json)?\s*(.+?)```", text, re.S)
    if m:
        text = m.group(1)
    i, j = text.find("["), text.rfind("]")
    return text[i:j + 1] if i >= 0 and j > i else text


def validate(batch: str, rows: list, index: dict) -> tuple[list, int]:
    """Return (problems, checks_made). Pure: no I/O, so the self-test can drive it."""
    problems, checks = [], 0
    spec = index.get(batch)
    if spec is None:
        return [{"code": "unknown_batch", "batch": batch}], 1
    want = {g["group_id"]: set(g["candidate_ids"]) for g in spec}

    seen = set()
    for r in rows:
        gid = r.get("group_id")
        checks += 1
        if gid not in want:
            problems.append({"code": "unknown_group", "batch": batch, "group": gid})
            continue
        checks += 1
        if gid in seen:
            problems.append({"code": "duplicate_group", "batch": batch, "group": gid})
            continue
        seen.add(gid)

        basis = r.get("basis")
        checks += 1
        if basis not in BASIS:
            problems.append({"code": "bad_basis", "batch": batch, "group": gid, "value": basis})

        rt = r.get("responds_to") or []
        checks += 1
        if not isinstance(rt, list):
            problems.append({"code": "responds_to_not_list", "batch": batch, "group": gid})
            rt = []

        for cid in rt:
            checks += 1
            if cid not in want[gid]:
                problems.append({"code": "hallucinated_candidate", "batch": batch,
                                 "group": gid, "candidate": cid})

        # A positive is exactly: basis is explicit/same_incident AND responds_to is
        # non-empty. `thematic` and `none` are both legitimately empty -- thematic
        # means "related but not a response", which the prompt asks for explicitly.
        checks += 1
        if (basis in POSITIVE_BASIS) != (len(rt) > 0):
            problems.append({"code": "basis_positive_mismatch", "batch": batch,
                             "group": gid, "basis": basis, "n_responds_to": len(rt)})
        checks += 1
        if basis == "thematic" and rt:
            problems.append({"code": "thematic_as_positive", "batch": batch, "group": gid})

        p = r.get("probability_pct")
        checks += 1
        if not isinstance(p, (int, float)) or isinstance(p, bool) or not (0 <= p <= 100):
            problems.append({"code": "bad_probability", "batch": batch, "group": gid, "value": p})
        elif (len(rt) > 0) != (p > 0):
            problems.append({"code": "probability_basis_mismatch", "batch": batch,
                             "group": gid, "basis": basis, "probability_pct": p})

    checks += 1
    for gid in want:
        if gid not in seen:
            problems.append({"code": "missing_group", "batch": batch, "group": gid})
    return problems, checks


# --------------------------------------------------------------------------- #
def self_test() -> int:
    idx = {"judge-001": [
        {"group_id": "G1", "candidate_ids": ["C1", "C2"]},
        {"group_id": "G2", "candidate_ids": ["C3"]},
    ]}
    clean = [
        {"group_id": "G1", "responds_to": ["C1"], "probability_pct": 80,
         "basis": "same_incident", "reasoning": "x"},
        {"group_id": "G2", "responds_to": [], "probability_pct": 0,
         "basis": "none", "reasoning": "y"},
    ]
    p, c = validate("judge-001", clean, idx)
    assert p == [], "clean input produced problems: %s" % p
    assert c >= 12, "clean input only made %d checks -- validation is near-vacuous" % c
    print("  clean input          : 0 problems, %d checks made   OK" % c)

    # A valid `thematic` row is empty and scores 0. An earlier version of this
    # validator rejected it, which only surfaced in an end-to-end smoke test --
    # so it is now a first-class case here.
    thematic = [clean[0], {"group_id": "G2", "responds_to": [], "probability_pct": 0,
                           "basis": "thematic", "reasoning": "related, not a response"}]
    p2, _ = validate("judge-001", thematic, idx)
    assert p2 == [], "valid thematic row rejected: %s" % p2
    print("  valid thematic row   : 0 problems   OK")

    cases = {
        "unknown_group": [dict(clean[0], group_id="NOPE"), clean[1]],
        "duplicate_group": [clean[0], clean[0], clean[1]],
        "bad_basis": [dict(clean[0], basis="maybe"), clean[1]],
        "hallucinated_candidate": [dict(clean[0], responds_to=["C99"]), clean[1]],
        "basis_positive_mismatch": [dict(clean[0], basis="none"), clean[1]],
        "thematic_as_positive": [dict(clean[0], basis="thematic"), clean[1]],
        "bad_probability": [dict(clean[0], probability_pct=140), clean[1]],
        "probability_basis_mismatch": [dict(clean[0], probability_pct=0), clean[1]],
        "missing_group": [clean[0]],
        "responds_to_not_list": [dict(clean[0], responds_to="C1"), clean[1]],
    }
    failed = 0
    for code, rows in cases.items():
        probs, _ = validate("judge-001", rows, idx)
        got = sorted({x["code"] for x in probs})
        ok = code in got
        failed += (not ok)
        print("  %-27s: %s   %s" % (code, "caught" if ok else "MISSED", got))
    print("\nself-test: %d defects, %d caught, %d missed" % (len(cases), len(cases) - failed, failed))
    return 1 if failed else 0


# --------------------------------------------------------------------------- #
def smoke_test(index_path: Path) -> int:
    """End-to-end run against the real index with synthetic replies, in a temp dir.

    Deliberately not written next to the real judgments: synthetic result files
    that live alongside real ones get mistaken for real ones later.
    """
    import random
    import shutil
    import tempfile

    index = json.loads(index_path.read_text(encoding="utf-8"))
    batches = sorted(index)[:2]
    rng = random.Random(7)
    tmp = Path(tempfile.mkdtemp(prefix="xdoc-smoke-"))
    try:
        for b in batches:
            rows = []
            for g in index[b]:
                if rng.random() < 0.15:
                    rows.append({"group_id": g["group_id"],
                                 "responds_to": [g["candidate_ids"][0]],
                                 "probability_pct": rng.choice([72, 80, 85, 91]),
                                 "basis": rng.choice(["explicit", "same_incident"]),
                                 "reasoning": "synthetic"})
                else:
                    rows.append({"group_id": g["group_id"], "responds_to": [],
                                 "probability_pct": 0,
                                 "basis": rng.choice(["none", "none", "thematic"]),
                                 "reasoning": "synthetic"})
            # emulate a real reply: leading prose and a fenced block
            (tmp / (b + ".json")).write_text(
                "Here are the judgments:\n\n```json\n" + json.dumps(rows, indent=1) + "\n```\n",
                encoding="utf-8")
        probs, checks, groups = 0, 0, 0
        for f in sorted(tmp.glob("judge-*.json")):
            rows = json.loads(strip_fences(f.read_text(encoding="utf-8")))
            p, c = validate(f.stem, rows, index)
            probs += len(p)
            checks += c
            groups += len(rows)
            if p:
                print("  %s: %s" % (f.stem, [x["code"] for x in p][:5]))
        ok = probs == 0 and checks > 0
        print("  end-to-end: %d groups, %d checks, %d problems   %s"
              % (groups, checks, probs, "OK" if ok else "FAIL"))
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--judgments", type=Path, default=HERE / "judgments")
    ap.add_argument("--index", type=Path, default=HERE / "judge-index.json")
    args = ap.parse_args()

    if args.self_test:
        rc = self_test()
        print()
        rc |= smoke_test(args.index)
        sys.exit(rc)

    index = json.loads(args.index.read_text(encoding="utf-8"))
    files = sorted(args.judgments.glob("judge-*.json"))
    if not files:
        sys.exit("no judgment files in %s" % args.judgments)

    all_problems, checks, rows_by_batch = [], 0, {}
    for f in files:
        raw = f.read_text(encoding="utf-8")
        try:
            rows = json.loads(strip_fences(raw))
        except json.JSONDecodeError as e:
            all_problems.append({"code": "unparseable", "batch": f.stem, "error": str(e)})
            continue
        if not isinstance(rows, list):
            all_problems.append({"code": "not_a_list", "batch": f.stem})
            continue
        p, c = validate(f.stem, rows, index)
        all_problems += p
        checks += c
        rows_by_batch[f.stem] = rows

    # ---- edges -------------------------------------------------------------
    edges, basis_mix, probs = [], Counter(), []
    groups_seen = groups_positive = 0
    bad_groups = {(x.get("batch"), x.get("group")) for x in all_problems}
    for batch, rows in rows_by_batch.items():
        for r in rows:
            if (batch, r.get("group_id")) in bad_groups:
                continue
            groups_seen += 1
            basis_mix[r.get("basis")] += 1
            if r.get("basis") in POSITIVE_BASIS and r.get("responds_to"):
                groups_positive += 1
                probs.append(r.get("probability_pct"))
                for cid in r["responds_to"]:
                    edges.append({"src_id": r["group_id"], "dst_id": cid,
                                  "relation": "respondsTo", "basis": r["basis"],
                                  "confidence_pct": r.get("probability_pct"),
                                  "extraction_method": "xdoc_chat_judge", "batch": batch})

    pairs_offered = sum(len(g["candidate_ids"])
                        for b in rows_by_batch if b in index for g in index[b])
    rate = groups_positive / max(1, groups_seen)
    verdict = (">=10%: proceed with the remaining batches" if rate >= 0.10 else
               "5-10%: marginal -- L1 holds under optimistic selection only" if rate >= 0.05 else
               "<5%: stop; links are not there at this blocking")

    report = {
        "batches_ingested": len(rows_by_batch), "groups_seen": groups_seen,
        "pairs_offered": pairs_offered, "checks_made": checks,
        "problems": len(all_problems),
        "problem_mix": dict(Counter(x["code"] for x in all_problems)),
        "problem_examples": all_problems[:10],
        "groups_with_a_positive": groups_positive,
        "positive_rate": round(rate, 4), "verdict_vs_dry_run": verdict,
        "basis_mix": dict(basis_mix), "edges_emitted": len(edges),
        "confidence_distinct": len(set(probs)), "confidence_constant": len(set(probs)) <= 1,
    }
    # Name outputs after the judgment set. Without this, ingesting a variant
    # silently overwrites the primary edge file, and the next downstream run
    # measures the variant while reporting as if it were the main set.
    tag = "" if args.judgments.name == "judgments" else "-" + args.judgments.name.replace("judgments-", "")
    (HERE / ("ingest-judgments-report%s.json" % tag)).write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    (HERE / ("xdoc-edges%s.json" % tag)).write_text(
        json.dumps(edges, indent=1, ensure_ascii=False), encoding="utf-8")
    print("outputs            : xdoc-edges%s.json" % tag)

    print("batches            : %d" % len(rows_by_batch))
    print("groups / pairs     : %d / %d" % (groups_seen, pairs_offered))
    print("checks made        : %d" % checks)
    print("problems           : %d  %s" % (len(all_problems),
                                           dict(Counter(x["code"] for x in all_problems))))
    print("basis mix          : %s" % dict(basis_mix))
    print("groups w/ positive : %d   rate %.1f%%" % (groups_positive, rate * 100))
    print("edges emitted      : %d   confidence distinct %d" % (len(edges), len(set(probs))))
    print("\nverdict: %s" % verdict)


if __name__ == "__main__":
    main()
