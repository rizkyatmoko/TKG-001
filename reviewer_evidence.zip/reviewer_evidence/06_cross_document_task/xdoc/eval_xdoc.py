"""Evaluate an R-GCN against heuristic baselines on the cross-document respondsTo task.

Candidate sets
--------------
Judging offered ~3 blocked candidates per response, far too few to rank: random
alone scores MRR 0.49 and Hits@3 0.74 on sets that small. The judge only had to
identify the *positive*, so negatives are widened at evaluation time: up to 100
drawn from all temporally admissible disruption incidents -- standard
KG-completion practice. Filtered ranking: incidents reported in the response's
own article are excluded, as is every incident judged positive for the response.
Tied scores receive their expected rank within the tie (see rr()).

Guards
------
G1  Target-edge masking. Every respondsTo edge is removed from message passing:
    the intra-article ones the view carries, and the cross-document positives,
    which the view never carries. Without this the model reads the answer off
    the adjacency it stands on. --leak-test puts them all back.
G2  No evidence text as a feature. The labels were assigned by a judge reading
    those quotes; using them would measure mind-reading, not structure.
G3  Blocked folds. Instances are sorted by response date and cut into contiguous
    folds; each fold is scored by a model trained on all the others, LATER folds
    included. This is blocked cross-validation, not a forecasting protocol.
    Intra-article training positives (--train-intra) are held to a stricter rule:
    admitted to a fold only if they predate its earliest test response.
G4  Incidents, not reports. Candidates are coreference-canonical incidents
    (news-tkg-gnn/coref-with-chat.json), so no candidate set holds a second
    report of the gold incident. The first version drew negatives from raw
    mentions: 19 of 65 sets held such duplicates, 142 in all, each scored as a
    wrong answer for every system. --raw-mentions reproduces that protocol.

Message passing uses the full graph at every query time. Report-time constrained
neighbourhoods are part of the resource's protocol but are NOT applied here.

Significance
------------
Per-instance reciprocal ranks are pooled across folds, giving n = every labelled
instance rather than one held-out split. The model is compared against the
strongest baseline with a paired percentile bootstrap and a sign-flip
permutation test, both from paired_stats.py.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent / "news-tkg-gnn"))
from rgcn import RGCN                      # noqa: E402
from paired_stats import compare           # noqa: E402

COREF = HERE.parent / "news-tkg-gnn" / "coref-with-chat.json"
WILD = {"broad_food", "unclear", "", None}
DISTRICTS = ["surabaya", "bangkalan", "banyuwangi", "batu", "blitar", "bojonegoro",
             "bondowoso", "gresik", "jember", "jombang", "kediri", "lamongan", "lumajang",
             "madiun", "magetan", "malang", "mojokerto", "nganjuk", "ngawi", "pacitan",
             "pamekasan", "pasuruan", "ponorogo", "probolinggo", "sampang", "sidoarjo",
             "situbondo", "sumenep", "trenggalek", "tuban", "tulungagung", "madura"]


def hardness(r, c):
    same_c = r["commodity"] == c["commodity"]
    compat = same_c or r["commodity"] in WILD or c["commodity"] in WILD
    same_l = r["district"] == c["district"] and r["district"] != "_other_"
    same_s = r["stage"] == c["stage"]
    lag = (r["date"] - c["date"]).days
    rec = max(0.0, 2.0 - min(lag, 730) / 365.0)
    return 4.0 * same_c + 2.0 * compat + 1.5 * same_l + 0.5 * same_s + rec


def b_random(r, cs, rng):
    return [rng.random() for _ in cs]


def b_recency(r, cs, rng):
    return [-(r["date"] - c["date"]).days for c in cs]


def b_district(r, cs, rng):
    return [(2.0 if c["district"] == r["district"] and r["district"] != "_other_" else 0.0)
            - (r["date"] - c["date"]).days / 10000.0 for c in cs]


def b_commodity(r, cs, rng):
    return [(2.0 if r["commodity"] == c["commodity"] else 0.0)
            - (r["date"] - c["date"]).days / 10000.0 for c in cs]


def b_hardness(r, cs, rng):
    return [hardness(r, c) for c in cs]


BASELINES = {"random": b_random, "recency": b_recency, "district": b_district,
             "commodity": b_commodity, "hardness": b_hardness}


def rr(scores, gold_ix):
    """1/rank of the gold, with tied candidates giving the gold its expected rank."""
    g = scores[gold_ix]
    better = sum(1 for s in scores if s > g)
    tied = sum(1 for i, s in enumerate(scores) if s == g and i != gold_ix)
    return 1.0 / (better + tied / 2.0 + 1.0)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--negatives", type=int, default=100)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--epochs", type=int, default=400)
    ap.add_argument("--hidden", type=int, default=32)
    ap.add_argument("--lr", type=float, default=0.05)
    ap.add_argument("--seed", type=int, default=20260829)
    ap.add_argument("--train-intra", action="store_true",
                    help="add the intra-article respondsTo positives as TRAINING "
                         "signal only. They are degenerate as a benchmark (median 0 "
                         "competitors) but are ordinary supervision; they never enter "
                         "the evaluation set and stay masked from message passing.")
    ap.add_argument("--leak-test", action="store_true",
                    help="disable G1 target masking, to show what the guard is worth")
    ap.add_argument("--raw-mentions", action="store_true",
                    help="reproduce the original protocol: candidates are raw disruption "
                         "mentions, so a set can hold another report of the gold incident")
    args = ap.parse_args()

    import scope_candidates as S

    evs = S.evs
    by_id = {e["event_id"]: e for e in evs}
    dis_all = [e for e in evs if e["is_dis"] and e["date"]]

    edges = json.loads((HERE / "xdoc-edges.json").read_text(encoding="utf-8"))
    gold = {}
    positives_of = defaultdict(set)
    for e in edges:
        positives_of[e["src_id"]].add(e["dst_id"])
        gold.setdefault(e["src_id"], e["dst_id"])

    # ---- G4: one candidate per incident ------------------------------------
    canon_full = {}
    for c in json.loads(COREF.read_text(encoding="utf-8")).get("cluster_members", []):
        for m in c["members"]:
            canon_full[m] = c["canonical"]
    canon = {} if args.raw_mentions else canon_full

    def can(eid):
        return canon.get(eid, eid)

    members = defaultdict(list)                  # insertion order follows dis_all
    for e in dis_all:
        members[can(e["event_id"])].append(e)
    incidents = {}
    for k, ms in members.items():
        rec = dict(by_id[k]) if k in by_id else dict(ms[0])
        rec["event_id"] = k
        rec["date"] = min(m["date"] for m in ms)          # the incident happened once
        rec["articles"] = {m["article"] for m in ms}      # every report of it
        incidents[k] = rec
    inc_all = list(incidents.values())

    rng = random.Random(args.seed)
    instances = []
    for src, g in gold.items():
        r, gd = by_id.get(src), incidents.get(can(g))
        if not r or not gd or not r["date"]:
            continue
        gold_keys = {can(p) for p in positives_of[src]}
        pool = [c for c in inc_all
                if c["event_id"] not in gold_keys and c["date"] <= r["date"]
                and r["article"] not in c["articles"]]
        rng.shuffle(pool)
        cands = [gd] + pool[:args.negatives]
        if len(cands) < 2:
            continue
        instances.append({"src": src, "gold": gd["event_id"], "cands": cands,
                          "date": r["date"], "r": r})

    # audit G4 against the full coreference map, whatever the protocol
    dup_of_gold = sum(
        1 for x in instances for c in x["cands"][1:]
        if canon_full.get(c["event_id"], c["event_id"]) == canon_full.get(x["gold"], x["gold"]))
    print(f"G4 audit: negatives that are another report of the gold incident: {dup_of_gold}")
    if not args.raw_mentions:
        assert dup_of_gold == 0, "G4 violated: a candidate set holds a report of its gold incident"

    # ---- optional extra training supervision -------------------------------
    intra = []
    if args.train_intra:
        def take(a, out):
            aid = a.get("candidate_id")
            slot = {e.get("event_slot"): (e.get("event_id") or
                    f"{aid}:llm:event:{e.get('event_slot')}") for e in a.get("events") or []}
            for rel in a.get("relations") or []:
                if (rel.get("predicate") or rel.get("relation")) != "respondsTo":
                    continue
                out.append((rel.get("subject_event_id") or slot.get(rel.get("subject_event_slot")),
                            rel.get("object_event_or_policy_id")
                            or slot.get(rel.get("object_event_slot"))))
        pairs = []
        for a in json.loads(S.PILOT.read_text(encoding="utf-8"))["annotations"]:
            take(a, pairs)
        for f_ in sorted(S.CKPT.glob("ann_*.json")):
            try:
                c = json.loads(f_.read_text(encoding="utf-8"))
            except Exception:
                continue
            if c.get("status") == "complete" and c.get("annotation"):
                take(c["annotation"], pairs)
        import os as _os
        if _os.environ.get("TKG_WITH_CHAT"):
            for f_ in sorted(S.CHAT.glob("ann_*.json")):
                try:
                    c = json.loads(f_.read_text(encoding="utf-8"))
                except Exception:
                    continue
                if c.get("annotation"):
                    take(c["annotation"], pairs)
        seen_src = {x["src"] for x in instances}
        for s_, o_ in pairs:
            r_, d_ = by_id.get(s_), by_id.get(o_)
            if not r_ or not d_ or not r_["date"] or not d_["date"]:
                continue
            if d_["date"] > r_["date"] or s_ in seen_src:
                continue                    # never train on an evaluated response
            gi = incidents.get(can(o_)) or dict(d_, articles={d_["article"]})
            pool = [c for c in inc_all if c["event_id"] != gi["event_id"] and c["date"] <= r_["date"]]
            rng.shuffle(pool)
            if not pool:
                continue
            intra.append({"src": s_, "gold": gi["event_id"], "cands": [gi] + pool[:args.negatives],
                          "date": r_["date"], "r": r_})
        print(f"extra training supervision: {len(intra)} intra-article positives "
              f"(evaluation set untouched)")

    instances.sort(key=lambda x: x["date"])
    for i, ins in enumerate(instances):
        ins["fold"] = i * args.folds // len(instances)
    sizes = [len(x["cands"]) for x in instances]
    print(f"protocol {'raw mentions' if args.raw_mentions else 'incidents'}   "
          f"instances {len(instances)}   candidates/instance median "
          f"{sorted(sizes)[len(sizes)//2]}, min {min(sizes)}")
    print(f"folds {args.folds}   negatives sampled per instance: up to {args.negatives}   "
          f"epochs {args.epochs}   hidden {args.hidden}   lr {args.lr}\n")

    # ---- baselines ---------------------------------------------------------
    per = {}
    for name, fn in BASELINES.items():
        brng = random.Random(args.seed)
        per[name] = [rr(fn(x["r"], x["cands"], brng),
                        [c["event_id"] for c in x["cands"]].index(x["gold"]))
                     for x in instances]

    # ---- R-GCN over the real typed graph -----------------------------------
    # The first version of this built a synthetic district clique because G1 masks
    # every respondsTo positive, leaving the event-only graph empty. That clique
    # made all events in a district converge to the same embedding -- destroying
    # exactly the signal the district baseline exploits, and the model scored
    # Hits@1 = 0. The graph to propagate over is the modelling view's own typed
    # edges: occursIn, concernsCommodity, hasActor, reportedIn, sourcePublisher.
    VIEW = HERE.parent / "news-tkg-modeling-view" / "view-chat-coref"
    import csv

    def vread(name):
        with (VIEW / name).open(encoding="utf-8") as f:
            return list(csv.DictReader(f, delimiter="\t"))

    view_edges = vread("edges.tsv")
    nodes = sorted({e["event_id"] for e in evs}
                   | {r["src_id"] for r in view_edges} | {r["dst_id"] for r in view_edges})
    idx = {n: i for i, n in enumerate(nodes)}
    N = len(nodes)

    coms = sorted({e["commodity"] for e in evs if e["commodity"]})
    stages = sorted({e["stage"] for e in evs if e["stage"]})
    F = 3 + len(coms) + len(stages) + len(DISTRICTS) + 2
    X = np.zeros((N, F))
    for e in evs:
        i = idx.get(e["event_id"])
        if i is None:
            continue
        X[i, 0] = float(e["is_dis"]); X[i, 1] = float(not e["is_dis"])
        if e["commodity"] in coms:
            X[i, 3 + coms.index(e["commodity"])] = 1.0
        if e["stage"] in stages:
            X[i, 3 + len(coms) + stages.index(e["stage"])] = 1.0
        if e["district"] in DISTRICTS:
            X[i, 3 + len(coms) + len(stages) + DISTRICTS.index(e["district"])] = 1.0
        if e["date"]:
            X[i, -2] = (e["date"].year - 2021) / 6.0
            X[i, -1] = e["date"].month / 12.0
    ev_ids = {e["event_id"] for e in evs}
    for n, i in idx.items():
        if n not in ev_ids:
            X[i, 2] = 1.0                     # non-event node marker

    # G1. Normally every respondsTo edge is dropped from message passing. Under
    # --leak-test they are put back, which is the point: a guard whose test cannot
    # fail is not a guard. An earlier version of this block dropped respondsTo
    # unconditionally, so the leak test silently reproduced the masked run.
    rels = sorted({r["relation"] for r in view_edges})
    buckets = defaultdict(list)
    n_leaked = 0
    for r in view_edges:
        if r["relation"] == "respondsTo" and not args.leak_test:
            continue
        s_, o_ = idx.get(r["src_id"]), idx.get(r["dst_id"])
        if s_ is not None and o_ is not None:
            buckets[r["relation"]].append((s_, o_))
            n_leaked += (r["relation"] == "respondsTo")
    if args.leak_test:
        # the cross-document positives themselves, which the view does not carry
        for e in edges:
            s_, o_ = idx.get(e["src_id"]), idx.get(e["dst_id"])
            if s_ is not None and o_ is not None:
                buckets["respondsTo"].append((s_, o_))
                n_leaked += 1
    # Sparse: 3,398 nodes x 9 relations dense would be 0.8 GB and minutes per epoch,
    # for a graph with 6,489 edges. RGCN only ever does A @ X and A.T @ ..., both
    # of which scipy's CSR supports.
    import scipy.sparse as sp
    adj = {}
    for r in rels:
        pairs = buckets.get(r, ())
        if not pairs:
            continue
        rows = [b for a, b in pairs] + [a for a, b in pairs]
        cols = [a for a, b in pairs] + [b for a, b in pairs]
        A = sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(N, N))
        A.sum_duplicates()
        A.data[:] = 1.0
        dg = np.asarray(A.sum(1)).ravel(); dg[dg == 0] = 1.0
        adj[r] = sp.diags(1.0 / dg) @ A
    kept_rels = [r for r in rels if buckets.get(r)]
    print(f"graph: {N} nodes, {len(kept_rels)} relations "
          f"({sum(len(v) for v in buckets.values())} edges), "
          f"respondsTo {'LEAKED: %d edges visible' % n_leaked if args.leak_test else 'fully masked'}")

    rgen = np.random.default_rng(args.seed)
    net = RGCN(F, args.hidden, kept_rels, out=args.hidden, relations="typed", seed=args.seed)
    We = rgen.normal(0, np.sqrt(2.0 / (3 * args.hidden)), (3 * args.hidden, 1))
    trained_params = (len(kept_rels) + 1) * (F * args.hidden + args.hidden * args.hidden) \
        + 3 * args.hidden

    model_rr = [0.0] * len(instances)
    fold_detail = []
    for f in range(args.folds):
        te = [x for x in instances if x["fold"] == f]
        if not te:
            continue
        t0 = min(y["date"] for y in te)
        tr_x = [x for x in instances if x["fold"] != f]
        tr_i = [x for x in intra if x["date"] < t0]
        tr = tr_x + tr_i
        fold_detail.append({"fold": f, "test": len(te), "train_crossdoc": len(tr_x),
                            "train_from_later_folds": sum(1 for x in tr_x if x["fold"] > f),
                            "train_intra_admitted": len(tr_i)})
        if not tr:
            continue
        net_f = RGCN(F, args.hidden, kept_rels, out=args.hidden, relations="typed",
                     seed=args.seed + f)
        We_f = We.copy()
        for ep in range(args.epochs):
            H = net_f.forward_embed(X, adj)
            si, oi, y = [], [], []
            for x in tr:
                s = idx[x["src"]]
                si.append(s); oi.append(idx[x["gold"]]); y.append(1.0)
                neg = x["cands"][1:][:12]
                for c in neg:
                    si.append(s); oi.append(idx[c["event_id"]]); y.append(0.0)
            si = np.array(si); oi = np.array(oi); y = np.array(y)[:, None]
            Z = np.hstack([H[si], H[oi], H[si] * H[oi]])
            logit = Z @ We_f
            p = 1.0 / (1.0 + np.exp(-np.clip(logit, -30, 30)))
            dl = (p - y) / len(y)
            gWe = Z.T @ dl
            dZ = dl @ We_f.T
            dH = np.zeros_like(H)
            k = args.hidden
            np.add.at(dH, si, dZ[:, :k] + dZ[:, 2 * k:] * H[oi])
            np.add.at(dH, oi, dZ[:, k:2 * k] + dZ[:, 2 * k:] * H[si])
            g = net_f.backward_from_dH2(dH)
            net_f.step(g, args.lr)
            We_f -= args.lr * gWe
        H = net_f.forward_embed(X, adj)
        for x in te:
            s = idx[x["src"]]
            oi = np.array([idx[c["event_id"]] for c in x["cands"]])
            Z = np.hstack([np.repeat(H[s][None], len(oi), 0), H[oi],
                           H[s][None] * H[oi]])
            sc = (Z @ We_f).ravel().tolist()
            model_rr[instances.index(x)] = rr(sc, 0)
    per["rgcn"] = model_rr

    print(f"{'system':12s} {'MRR':>7s} {'Hits@1':>8s} {'Hits@10':>8s}")
    summary = {}
    for name, v in per.items():
        mrr = sum(v) / len(v)
        h1 = sum(1 for x in v if x == 1.0) / len(v)
        h10 = sum(1 for x in v if x >= 0.1) / len(v)
        summary[name] = {"mrr": round(mrr, 4), "hits1": round(h1, 4), "hits10": round(h10, 4)}
        print(f"{name:12s} {mrr:7.3f} {h1:8.3f} {h10:8.3f}")

    best_base = max((k for k in per if k != "rgcn"), key=lambda k: summary[k]["mrr"])
    print(f"\nstrongest baseline: {best_base} (MRR {summary[best_base]['mrr']:.3f})")
    st = compare(per["rgcn"], per[best_base], "rgcn", best_base)
    print(json.dumps(st, indent=2)[:900])

    # Output names never collide with the original raw-mention results
    # (eval-xdoc*.json), which are kept as the record of the flawed protocol.
    stem = "eval-raw" if args.raw_mentions else "eval-canon"
    out = HERE / (stem + ("-leaktest" if args.leak_test else "")
                  + ("-intra" if args.train_intra else "") + ".json")
    out.write_text(
        json.dumps({"protocol": "raw_mentions" if args.raw_mentions else "incidents",
                    "instances": len(instances), "negatives": args.negatives,
                    "folds": args.folds, "epochs": args.epochs, "hidden": args.hidden,
                    "lr": args.lr, "seed": args.seed,
                    "leak_test": args.leak_test, "train_intra": args.train_intra,
                    "extra_training_positives": len(intra),
                    "dup_of_gold_negatives": dup_of_gold,
                    "median_candidates": sorted(sizes)[len(sizes) // 2],
                    "min_candidates": min(sizes),
                    "graph": {"nodes": N, "relations": len(kept_rels), "features": F,
                              "trained_parameters": trained_params},
                    "fold_detail": fold_detail,
                    "per_instance_rr": per,
                    "results": summary, "strongest_baseline": best_base,
                    "paired_test_rgcn_vs_baseline": st}, indent=2), encoding="utf-8")
    print(f"wrote {out.name}")


if __name__ == "__main__":
    main()
