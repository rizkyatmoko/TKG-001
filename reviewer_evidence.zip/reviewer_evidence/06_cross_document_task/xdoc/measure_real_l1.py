"""L1 on the judged cross-document positives -- real data, not simulation."""
import json
from pathlib import Path
import scope_candidates as S

WILD = S.WILD
evs = S.evs
by_id = {e["event_id"]: e for e in evs}
dis = [e for e in evs if e["is_dis"] and e["date"]]


def hardness(r, c):
    same_c = r["commodity"] == c["commodity"]
    compat = same_c or r["commodity"] in WILD or c["commodity"] in WILD
    same_l = r["district"] == c["district"] and r["district"] != "_other_"
    same_s = r["stage"] == c["stage"]
    lag = (r["date"] - c["date"]).days
    rec = max(0.0, 2.0 - min(lag, 730) / 365.0)
    return 4.0 * same_c + 2.0 * compat + 1.5 * same_l + 0.5 * same_s + rec


def competitors(r, pos):
    h = hardness(r, pos)
    return sum(1 for c in dis if c is not pos and c["date"] <= r["date"]
               and c["article"] != r["article"] and hardness(r, c) >= h)


edges = json.loads(Path("xdoc-edges.json").read_text(encoding="utf-8"))
rows = []
for e in edges:
    r, p = by_id.get(e["src_id"]), by_id.get(e["dst_id"])
    if r and p and r["date"] and p["date"]:
        rows.append((competitors(r, p), hardness(r, p), e["basis"], e["confidence_pct"]))

cao = sorted(x[0] for x in rows)
sh = sum(1 for x in cao if x == 0) / len(cao)
med = cao[len(cao) // 2]
print(f"judged cross-document positives : {len(rows)}")
print(f"competitors at-or-above positive : {cao}")
print(f"strictly hardest                 : {sh:.0%}   (gate: < 80%)")
print(f"median competitors               : {med}     (gate: >= 1)")
print(f"L1                               : {'PASS' if sh < 0.80 and med >= 1 else 'FAIL'}")
print()
print(f"positive hardness range          : {min(x[1] for x in rows):.2f} - {max(x[1] for x in rows):.2f}")
print("  (intra-article positives sit near the 10.0 ceiling by construction)")
print()
judged = len(json.loads(Path("ingest-judgments-report.json").read_text(encoding="utf-8"))
             and json.loads(Path("ingest-judgments-report.json").read_text(encoding="utf-8")))
rep = json.loads(Path("ingest-judgments-report.json").read_text(encoding="utf-8"))
g_seen, g_total = rep["groups_seen"], 278
if g_seen >= g_total:
    print(f"all {g_total} groups judged        : {len(rows)} cross-document positives (final)")
else:
    print(f"judged {g_seen} of {g_total} groups     : projecting ~{round(len(rows)/g_seen*g_total)}")
print(f"L2 single split (needs 215)      : {'PASS' if len(rows) >= 215 else 'FAIL'}")
print(f"L2 via k-fold CV pooled          : n={len(rows)}  -> powered for dz ~ {2.8/max(1,len(rows))**0.5:.2f}")
