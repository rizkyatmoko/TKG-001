"""Does the Layer-1 verdict depend on how an incident is represented? (read-only)

measure_l1_incidents.py found that the cross-document task passes Layer 1 when
competitors are counted as raw mentions (29% strictly hardest, median 3) and
fails it when they are counted as incidents (52%, median 0). Five ways of
counting, from the published one to the one most generous to competitors:

  V0  mentions                                           (published)
  V1  mentions, minus other reports of the gold incident
  V2  incidents: canonical record, earliest date         (= eval_xdoc G4)
  V3  as V2, but the positive scored by the judged mention itself
  V4  as V3, and a competitor incident counts if ANY of its reports dated no
      later than the response reaches the positive's hardness

Every variant keeps the D6 filters: dated no later than the response, and not
reported in the response's own article. Writes l1-unit-sensitivity.json.
"""
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).parent
os.environ.setdefault("TKG_WITH_CHAT", "1")
sys.path.insert(0, str(HERE))
import scope_candidates as S  # noqa: E402  (prints its own table)

WILD = S.WILD


def hardness(r, c):  # identical to viability_check D6 and eval_xdoc
    same_c = r["commodity"] == c["commodity"]
    compat = same_c or r["commodity"] in WILD or c["commodity"] in WILD
    same_l = r["district"] == c["district"] and r["district"] != "_other_"
    same_s = r["stage"] == c["stage"]
    lag = (r["date"] - c["date"]).days
    rec = max(0.0, 2.0 - min(lag, 730) / 365.0)
    return 4.0 * same_c + 2.0 * compat + 1.5 * same_l + 0.5 * same_s + rec


evs = S.evs
by_id = {e["event_id"]: e for e in evs}
dis_all = [e for e in evs if e["is_dis"] and e["date"]]
canon = {}
for c in json.loads((HERE.parent / "news-tkg-gnn" / "coref-with-chat.json")
                    .read_text(encoding="utf-8")).get("cluster_members", []):
    for m in c["members"]:
        canon[m] = c["canonical"]


def can(x):
    return canon.get(x, x)


members = defaultdict(list)
for e in dis_all:
    members[can(e["event_id"])].append(e)
inc = {}
for k, ms in members.items():
    rec = dict(by_id[k]) if k in by_id else dict(ms[0])
    rec["event_id"] = k
    rec["date"] = min(m["date"] for m in ms)
    rec["articles"] = {m["article"] for m in ms}
    inc[k] = rec

xdoc = [(e["src_id"], e["dst_id"])
        for e in json.loads((HERE / "xdoc-edges.json").read_text(encoding="utf-8"))]


def competitors(variant, r, d0):
    gk = can(d0["event_id"])
    if variant in ("V0", "V1"):
        h = hardness(r, d0)
        return sum(1 for m in dis_all
                   if m["event_id"] != d0["event_id"] and m["date"] <= r["date"]
                   and m["article"] != r["article"] and hardness(r, m) >= h
                   and not (variant == "V1" and can(m["event_id"]) == gk))
    if variant == "V2":
        g = inc.get(gk) or dict(d0, articles={d0["article"]})
        h = hardness(r, g)
    else:
        h = hardness(r, d0)
    n = 0
    for k, c in inc.items():
        if k == gk or c["date"] > r["date"] or r["article"] in c["articles"]:
            continue
        if variant == "V4":
            n += any(m["date"] <= r["date"] and hardness(r, m) >= h for m in members[k])
        else:
            n += hardness(r, c) >= h
    return n


report = {}
print("\n" + "=" * 72)
print(f"{'variant':8s} {'pairs':>5s} {'strictly hardest':>17s} {'median comp':>12s} "
      f"{'mean comp':>10s}  L1")
for v in ("V0", "V1", "V2", "V3", "V4"):
    comps = []
    for s, o in xdoc:
        r, d0 = by_id.get(s), by_id.get(o)
        if not r or not d0 or not r["date"] or not d0["date"] or d0["date"] > r["date"]:
            continue
        comps.append(competitors(v, r, d0))
    comps.sort()
    n = len(comps)
    sh = sum(1 for x in comps if x == 0) / n
    med = comps[n // 2]
    ok = sh < 0.80 and med >= 1
    report[v] = {"pairs": n, "strictly_hardest": round(sh, 4), "zeros": comps.count(0),
                 "median_competitors": med, "L1_pass": bool(ok), "competitors_sorted": comps}
    print(f"{v:8s} {n:5d} {sh:16.1%} {med:12d} {sum(comps) / n:10.1f}  {'PASS' if ok else 'fail'}")
print("\nzeros needed for the median to reach 1: at most", (len(xdoc) - 1) // 2)
(HERE / "l1-unit-sensitivity.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print("wrote l1-unit-sensitivity.json")
