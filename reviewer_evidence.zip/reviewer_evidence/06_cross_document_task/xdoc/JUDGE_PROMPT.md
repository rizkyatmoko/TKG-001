# Cross-document respondsTo judging — paste this once at the start of a chat session

Then paste one `judge-batches/judge-XXX.txt` per turn. Reply to each with JSON only.

---

You are judging whether a government or institutional **response** to a
food-system problem in East Java was a response to a **specific disruption**
reported in a *different* news article.

Each group gives you one response event and several candidate disruption events.
They already share a district and the disruption already precedes the response —
that is only a filter, not evidence. Most groups will have **no** correct
candidate. Say so.

Return **only** a JSON array, one object per group, in the order given. No prose,
no markdown fences.

```json
[
  {
    "group_id": "ann_xxxx:llm:event:2",
    "responds_to": ["ann_yyyy:llm:event:1"],
    "probability_pct": 0,
    "basis": "explicit | same_incident | thematic | none",
    "reasoning": "one short sentence"
  }
]
```

## The judgment

Ask: **would a reader of both articles conclude this response was caused by, or
directed at, this particular disruption?** Not "are these related", not "are they
about the same commodity", not "could they plausibly co-occur".

Set `basis`:

| value | meaning |
|---|---|
| `explicit` | the response's own evidence names the disruption, its cause, or its damage |
| `same_incident` | both describe one identifiable occurrence — same flood, same outbreak, same seizure |
| `thematic` | same topic and place, but no identifiable shared occurrence |
| `none` | no candidate qualifies |

**`thematic` is not a positive.** Put it in `responds_to` only if `basis` is
`explicit` or `same_incident`. A drought-relief programme and a separate report of
drought in the same regency are `thematic` unless one clearly refers to the other's
occurrence.

## Guardrails, which exist because a previous judging round failed them

* **Default to `none`.** A single judge asked to find links finds them. In our
  coreference round one judge proposed 9 merges where a three-variant ensemble
  supported 1. If you are balancing reasons for and against, the answer is `none`.
* **Routine or standing activity is not a response.** Scheduled distributions,
  annual programmes, ongoing enforcement drives and general preparedness are not
  responses to any particular disruption, however well they match on place and date.
* **Shared category is not shared causation.** Two floods in Jember three weeks
  apart are two incidents. Proximity in the candidate list is a product of the
  filter.
* `responds_to` may hold more than one id, but only when the response genuinely
  addresses several distinct disruptions. This should be rare.
* `probability_pct` is your confidence for the whole group: 0 when `basis` is
  `none`, otherwise 1–100. Do not reuse one value everywhere.

## Worked examples

Response *"BPBD Sidoarjo distributed food packages to residents affected by the
flood"*, candidate *"Areas of Sidoarjo flooded by river overflow and tidal
backflow", lag 0d* → `same_incident`, positive. One occurrence, both sides.

Response *"Pemkab Lamongan accelerated planting and adopted drought-tolerant
varieties facing El Niño"*, candidate *"Long dry season cut chilli harvests in
Sumenep", lag 40d* → `thematic`, **not** a positive. Different regency-level
occurrence; the response addresses a forecast, not that harvest failure.

Response *"Polda Jatim named a Sidoarjo rice producer a suspect"*, candidate
*"Adulterated SPHP rice found in Probolinggo", lag 12d* → `none` unless the
evidence ties the two cases. Same enforcement campaign is not the same incident.
