"""Generate cross-document respondsTo candidates and the judging batches.

The task this unblocks
----------------------
Every respondsTo edge currently links two event slots inside one article, so all
200 positives are intra-article. Under the hardness function that is near-maximal
(same commodity, same district, tiny lag), which is why no cross-article
candidate ever reaches a positive and L1 fails with median 0 competitors.
Cross-document positives sit at ordinary hardness, drawn from the same blocked
pool as their negatives, so competitors can reach them.

Blocking
--------
Superset rule, deliberately looser than the task we expect to build:

    same district, disruption strictly before response, lag <= 180 days,
    different article

Commodity is NOT used to block. Judging is the expensive step and generation is
cheap, so we judge the superset once and subset afterwards -- a commodity-blocked
variant stays available without re-judging, and commodity remains a feature the
model must learn rather than a constraint baked into the candidate set.

Judging format
--------------
Grouped by response, not pairwise. The judge sees one response and all of its
candidate disruptions at once and picks which it responds to, with "none" always
available. That mirrors the ranking task, yields a natural ordering, and makes
the "responds to nothing here" case explicit -- pairwise judging has no way to
express it and inflates the positive rate.

Read-only w.r.t. the ChatGPT folder.
"""

from __future__ import annotations

import json
import os
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

import scope_candidates as S

HERE = Path(__file__).parent
MAX_LAG = 180
GROUPS_PER_BATCH = 12
MAX_CANDS = 10          # cap a group; keeps a batch legible

evs = S.evs
by_article = defaultdict(list)
for e in evs:
    by_article[e["article"]].append(e)

# evidence quotes live in the raw annotations, not in S's event dicts
quotes: dict[str, str] = {}
titles: dict[str, str] = {}


def _harvest(arts):
    for a in arts:
        aid = a.get("candidate_id")
        titles[aid] = a.get("title") or ""
        for e in a.get("events") or []:
            eid = e.get("event_id") or f"{aid}:llm:event:{e.get('event_slot')}"
            quotes[eid] = (e.get("evidence_quote") or "").strip()


_harvest(json.loads(S.PILOT.read_text(encoding="utf-8"))["annotations"])
for p in sorted(S.CKPT.glob("ann_*.json")):
    try:
        c = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        continue
    if c.get("status") == "complete" and c.get("annotation"):
        _harvest([c["annotation"]])
if os.environ.get("TKG_WITH_CHAT"):
    for p in sorted(S.CHAT.glob("ann_*.json")):
        try:
            c = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if c.get("annotation"):
            _harvest([c["annotation"]])

resp = [e for e in evs if not e["is_dis"] and e["date"]]
dis_raw = [e for e in evs if e["is_dis"] and e["date"]]

# Collapse coreferent disruptions to one canonical node BEFORE building candidate
# sets. Without this the candidate list is per-article event *mentions*, so a
# response to the Semeru eruption is asked to rank ten reports of that eruption
# against each other -- an ill-posed ranking, and 10 of the first 12 groups were
# exactly that. Ranking is over distinct incidents, not over reports.
COREF = Path(__file__).parent.parent / "news-tkg-gnn" / "coref-with-chat.json"
canon: dict[str, str] = {}
if COREF.exists():
    for c in json.loads(COREF.read_text(encoding="utf-8")).get("cluster_members", []):
        for m in c["members"]:
            canon[m] = c["canonical"]

merged: dict[str, dict] = {}
for e in dis_raw:
    key = canon.get(e["event_id"], e["event_id"])
    cur = merged.get(key)
    # keep the earliest-dated mention as the canonical record: the incident
    # happened once, and the first report is the one a response could react to
    if cur is None or e["date"] < cur["date"]:
        rec = dict(e)
        rec["event_id"] = key
        rec["n_mentions"] = 1
        # Every article the cluster is reported in, not just the earliest one.
        # The canonical id can come from a different article than the retained
        # record, so a single "article" field lets a response match a mention
        # from its own article -- a self-match that is not judgeable.
        rec["articles"] = set(cur["articles"]) | {e["article"]} if cur else {e["article"]}
        merged[key] = rec
    else:
        cur["n_mentions"] = cur.get("n_mentions", 1) + 1
        cur["articles"].add(e["article"])
    if key in merged:
        merged[key]["articles"].add(e["article"])
        merged[key]["articles"].add(key.split(":")[0])
dis = list(merged.values())
print(f"disruptions {len(dis_raw)} mentions -> {len(dis)} canonical "
      f"({len(dis_raw) - len(dis)} absorbed by coreference)")

bd = defaultdict(list)
for x in dis:
    bd[x["district"]].append(x)

groups = []
for r in resp:
    if r["district"] == "_other_":
        continue
    cands = [x for x in bd.get(r["district"], [])
             if r["article"] not in x.get("articles", {x["article"]})
             and 0 <= (r["date"] - x["date"]).days <= MAX_LAG]
    if not cands:
        continue
    # nearest in time first, capped; keeps the hardest candidates in the set
    cands.sort(key=lambda x: (r["date"] - x["date"]).days)
    groups.append({"response": r, "candidates": cands[:MAX_CANDS]})

groups.sort(key=lambda g: -len(g["candidates"]))    # richest groups first
pairs = sum(len(g["candidates"]) for g in groups)
print(f"responses {len(resp)}   disruptions {len(dis)}")
print(f"groups {len(groups)}   pairs {pairs}   "
      f"rankable(>=2) {sum(1 for g in groups if len(g['candidates']) >= 2)}")

OUT = HERE / "judge-batches"
OUT.mkdir(exist_ok=True)
for f in OUT.glob("judge-*.txt"):
    f.unlink()


def fmt_event(e, tag):
    q = quotes.get(e["event_id"], "")
    q = (q[:300] + "…") if len(q) > 300 else q
    return (f"  {tag}\n"
            f"    subtype   : {e['subtype']}\n"
            f"    date      : {e['date']}\n"
            f"    district  : {e['district']}\n"
            f"    commodity : {e['commodity']}\n"
            f"    publisher : {e['publisher']}\n"
            f"    evidence  : {q}\n")


index = {}
for bi in range(0, len(groups), GROUPS_PER_BATCH):
    n = bi // GROUPS_PER_BATCH + 1
    chunk = groups[bi:bi + GROUPS_PER_BATCH]
    lines = [f"JUDGE BATCH {n:03d} — {len(chunk)} response groups", ""]
    for k, g in enumerate(chunk, 1):
        r = g["response"]
        lines.append(f"===== GROUP {k} =====")
        lines.append(f"group_id: {r['event_id']}")
        lines.append(fmt_event(r, "RESPONSE"))
        lines.append(f"  CANDIDATE DISRUPTIONS ({len(g['candidates'])}):")
        for ci, c in enumerate(g["candidates"], 1):
            lag = (r["date"] - c["date"]).days
            lines.append(f"    [{ci}] lag {lag}d")
            lines.append(fmt_event(c, f"candidate_{ci}   id={c['event_id']}").rstrip())
        lines.append("")
    (OUT / f"judge-{n:03d}.txt").write_text("\n".join(lines), encoding="utf-8")
    index[f"judge-{n:03d}"] = [
        {"group_id": g["response"]["event_id"],
         "candidate_ids": [c["event_id"] for c in g["candidates"]]} for g in chunk]

(HERE / "judge-index.json").write_text(json.dumps(index, indent=1), encoding="utf-8")
nb = len(index)
print(f"wrote {nb} batches to judge-batches\  ({GROUPS_PER_BATCH} groups each)")
print(f"pilot: run judge-001 and judge-002 first — {sum(len(v) for k, v in list(index.items())[:2])} groups, "
      f"{sum(len(c['candidate_ids']) for k, v in list(index.items())[:2] for c in v)} pairs")
