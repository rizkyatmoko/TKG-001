# Cross-document respondsTo — input and output

Everything lives in `C:\Users\HP\Documents\Claude\news-tkg-xdoc\`.

## Why this exists

All 200 `respondsTo` edges are intra-article: the extractor links event slots
inside one article and never across articles. Under the hardness function an
intra-article positive is near-maximal (same commodity, same district, tiny lag),
so no cross-article candidate ever reaches it and **L1 fails with median 0
competitors**. That is the single blocker standing between this corpus and a
viable ranking task, and more extraction does not touch it — 2.3x the articles
moved the median from 0 to 0.

Cross-document positives are drawn from the same blocked pool as their negatives,
so competitors reach them by construction.

## INPUT

| # | File | When |
|---|---|---|
| 1 | `JUDGE_PROMPT.md` | **once**, at the start of a chat session |
| 2 | `judge-batches\judge-001.txt` … `judge-024.txt` | one per turn |

24 batches, 12 response-groups each: 279 groups, 1,006 candidate pairs. Groups
are ordered richest-first, so stopping early still leaves the useful half.

## OUTPUT

Save each reply verbatim to `judgments\judge-001.json`, matching the batch number.

## Before you paste anything

```bash
python ingest_judgments.py --self-test
```

10 synthetic defects, each caught by its own check, then an end-to-end run
against the real index with fenced synthetic replies. The end-to-end pass is not
decoration: it caught a validator bug the unit cases missed (a valid `thematic`
row -- empty, scoring 0 -- was being rejected as a mismatch).

## Run the pilot first

**Do batches 001 and 002 only** (24 groups, 233 pairs), then stop. The positive
rate decides whether the remaining 22 are worth running:

| observed positive rate | meaning | do |
|---|---|---|
| >= 8% | ~80 cross-doc positives from the full run; L2 clears at 280 total | run the rest |
| 3-8% | ~30-50; L2 marginal, L1 probably still improves | judge the call |
| < 3% | the blocking is too loose or the links are not there | stop, re-block |

That threshold is not a guess: L2 needs 215 `respondsTo` and there are 200
already, but the intra-article ones cannot fix L1 — only cross-document
positives can, and ~80 is where they stop being a rounding error.

## Directory map

```
news-tkg-xdoc\
├── JUDGE_PROMPT.md          INPUT  — paste once
├── judge-batches\           INPUT  — one per turn (24 files)
├── judgments\               OUTPUT — save replies here
├── scope_candidates.py      sizes the pool under 5 blocking rules
├── build_xdoc_candidates.py regenerates judge-batches\
├── ingest_judgments.py      judgments\ -> xdoc-edges.json  (--self-test)
├── dry_run_l1.py            simulates whether positives clear L1
├── judge-index.json         GENERATED — group -> candidate ids
├── candidate-scope.json     GENERATED — pool sizes
└── dry-run-l1.json          GENERATED — the simulation below
```

## Blocking rule

    same district + disruption strictly before response + lag <= 180d + different article

Commodity is deliberately **not** blocked. Judging is the expensive step and
generation is cheap, so the superset is judged once; a commodity-blocked variant
stays available afterwards without re-judging, and commodity stays a feature the
model must learn rather than a constant baked into every candidate set.

## Known wrinkle

Some events tagged as disruptions carry evidence quotes describing a *response*
(e.g. a Semeru eruption event whose quote is about aid being distributed). The
judge should return `none` for those. If the pilot shows this is common, the
disruption side needs a filter before the remaining 22 batches.

## After the judgments land

```bash
python ingest_judgments.py                    # judgments\ -> xdoc-edges.json
python build_xdoc_task.py                     # -> xdoc-task.json + baselines
```

`build_xdoc_task.py` runs four baselines before any model: random, recency,
commodity-match, and the **hardness function itself**. The last one is the real
test -- it is the heuristic that selected the candidates, so if it ranks the
positive first the task restates its own construction and a GNN number on it
would mean nothing. Verified both ways with fabricated labels:

| simulated labels | hardness MRR | Hits@1 | L0 |
|---|---:|---:|---|
| random (negative control) | 0.524 | 0.182 | pass |
| gold *is* the hardest candidate | 0.922 | 0.800 | **FAIL** |

Simulated runs refuse to write the task file.

## A candidate-set problem to fix at evaluation time

Instances carry a **median of 3 candidates** (mean 4.2). Random already scores
MRR ~0.56 and Hits@3 ~0.79 on sets that small, so Hits@3 is close to
uninformative and the headroom above chance is thin.

The fix costs no extra judging. The judge only has to identify the *positive*;
negatives can be drawn far more widely at evaluation time from the unjudged
disruption pool, which is standard KG-completion practice. Keep the blocked set
for judging, then rank the gold against 50-100 sampled negatives per instance.
That restores a meaningful ranking task without another batch.

## What the dry run already told us

`dry_run_l1.py` injects hypothetical positives at several rates and reports what
L1 would read. No configuration passes both gates:

| positives used | L1 integrity | L2 power |
|---|---|---|
| pooled (198 intra-article + cross-doc) | **fail** — median 0 competitors at every rate | pass |
| cross-document only | **pass** — median 18-56 competitors, 10-19% strictly hardest | **fail** — max 69 vs 215 |

The 198 intra-article positives are what give the benchmark its count and also
what drags the median competitor to 0. Cross-document-only is the sound task and
it clears L1 decisively; its power shortfall is an evaluation-design problem
(k-fold CV pooled across folds gives n = all positives, ~69, powered for
dz ~ 0.35) rather than an extraction problem. Reaching 215 cross-document
positives by extraction needs roughly 3x the candidate groups, about 2,000 more
articles.

One row is worth reading before trusting the plan: **pessimistic at 5% fails L1
too**. If true positives are both rare and always the single hardest candidate,
even the clean task degenerates. That is what the pilot measures.
