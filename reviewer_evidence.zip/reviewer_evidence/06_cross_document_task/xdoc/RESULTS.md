# Cross-document respondsTo — results

Corpus: 2,235 articles (955 qwen3:8b + pilot, 1,280 chatbot), 1,107 events,
coreference-merged to 462 canonical disruptions.

## Dataset

| | value |
|---|---|
| response groups judged | 278 |
| candidate pairs judged | 802 |
| validation checks / problems | 2,035 / 0 |
| cross-document positives | **65** (23.4% of groups) |
| basis mix | 48 `same_incident`, 17 `explicit`, 0 `thematic` |
| distinct disruption targets | 38 |
| top-target share | 17% (top-3: 29%) |

Judged by Claude Opus 5 under `JUDGE_PROMPT.md`. **Silver labels, single judge** —
this must be declared. A necessity-framed second variant (`JUDGE_PROMPT_VARIANT_B.md`)
on the first two batches gave kappa 0.800, pair Jaccard 0.750, 75% of variant A's
positives surviving. That check is contaminated: the same judge did both passes
knowing the first answers, so 0.800 is an upper bound.

## Admissibility gates

| gate | intra-article positives | cross-document positives |
|---|---|---|
| strictly hardest (< 0.80) | 61% | **29%** |
| median competitors (>= 1) | **0** | **3** |
| L1 verdict | FAIL | **PASS** |
| positive hardness | pinned near 10.0 ceiling | 3.46 – 10.00 |

This is the point of the whole cross-document detour. Intra-article positives are
near-maximally hard by construction — same commodity, same district, tiny lag —
so no candidate ever competes. Cross-document positives are drawn from the same
blocked pool as their negatives.

**L2 fails on a single split** (65 < 215). Carried by k-fold CV with per-instance
reciprocal ranks pooled across folds: n = 65, powered for dz ~ 0.35.

## Ranking results

65 instances, 101 candidates each (gold + 100 sampled unjudged negatives,
filtered), 5 temporal folds.

| system | MRR | Hits@1 | Hits@10 |
|---|---:|---:|---:|
| random | 0.088 | 0.031 | 0.169 |
| commodity match | 0.458 | 0.338 | 0.646 |
| hardness (selection function) | 0.467 | 0.354 | 0.646 |
| recency | 0.564 | 0.369 | 0.892 |
| **district match** | **0.717** | **0.538** | **0.954** |
| R-GCN | 0.259 | 0.154 | 0.431 |
| R-GCN + intra-article training | **0.325** | 0.246 | 0.431 |
| R-GCN, G1 disabled (leak test) | 0.346 | 0.200 | 0.723 |

Paired tests against the district baseline (bootstrap 20k, sign-flip permutation 20k):

| model | mean diff | 95% CI | p | dz |
|---|---:|---|---:|---:|
| R-GCN | −0.458 | [−0.604, −0.302] | 5e-05 | −1.544 |
| R-GCN + intra | −0.393 | [−0.553, −0.223] | 1e-04 | −0.576 |

**The R-GCN significantly underperforms a two-line heuristic**, on a task whose
integrity gate passes, with every fair advantage given: the real typed graph
(3,446 nodes, 9 relations, 6,289 edges), 5x the supervision, temporal folds,
wide negatives.

## What the guards are worth

Disabling G1 (target-edge masking) moves the model from MRR 0.259 to 0.346 and
Hits@10 from 0.431 to 0.723. The guard is load-bearing; 0.259 is the honest
number.

Worth noting: **legitimate extra supervision (0.325) buys about what cheating
does (0.346)**. The model is supervision-starved, not architecture-starved.

## Scaling

160 extra training positives (a ~4x increase in supervision) bought +0.066 MRR.
Closing the remaining 0.393 gap by extraction alone is not plausible: the
cross-document positive rate is 23% of groups, groups scale roughly with corpus
size, and the corpus would need to grow by an order of magnitude.

## Known defects

* 2 of 278 groups (0.7%) carried a self-match from coreference canonicalisation
  and were marked unjudgeable. `build_xdoc_candidates.py` is patched.
* 3 candidate ids were mistranscribed during judging; all three were caught by
  the ingester's exact-membership check and corrected.
* An earlier `--leak-test` silently reproduced the masked run, because the
  adjacency rewrite dropped `respondsTo` unconditionally. Fixed; the header now
  prints `LEAKED: N edges visible` versus `fully masked`.
* The first R-GCN build propagated over a synthetic district clique (the
  event-only graph is empty once G1 masks every positive). That collapsed all
  same-district events to one embedding and scored Hits@1 = 0.000. Replaced with
  the modelling view's typed edges.

## Reproduce

```bash
python ingest_judgments.py --self-test          # 10 defects + end-to-end
python ingest_judgments.py                      # judgments/ -> xdoc-edges.json
python measure_real_l1.py                       # L1 on the real positives
python build_xdoc_task.py                       # task + degeneracy baselines
python eval_xdoc.py --epochs 400 --hidden 32 --train-intra
python eval_xdoc.py --epochs 400 --hidden 32 --leak-test
```

All model runs need the system interpreter (numpy, scipy); the ChatGPT venv has
neither. `TKG_WITH_CHAT=1` includes the chatbot corpus.
