"""Build the cross-document respondsTo ranking task and run the degeneracy baselines.

What the task is
----------------
One instance per response group: rank that group's candidate disruptions, one of
which the judge marked a positive. This is the task the whole cross-document
detour exists to create, because the intra-article positives cannot support it --
they are near-maximally hard by construction, so no negative ever reaches them.

Why baselines come before the model
-----------------------------------
The candidate sets were built by a blocking rule and the hardness function that
scores them is a hand-written heuristic over commodity, district, stage and lag.
If that heuristic alone ranks the positive first, the task restates its own
construction and a GNN result on it would mean nothing -- the L0 failure that
killed relation classification, arriving by a different route. So four baselines
run first and the strongest of them is the number to beat:

  random        lower bound given group sizes
  recency       nearest disruption in time wins
  commodity     exact commodity match, ties broken by recency
  hardness      the full selection heuristic, i.e. the construction itself

`--simulate` fabricates labels so the harness can be exercised end to end before
any real judgment exists. Simulated runs are stamped `simulated: true` in the
report and refuse to write the task file.

Evaluation design
-----------------
k-fold cross-validation, folds assigned by response date so no fold trains on a
later fold's edges, with per-instance reciprocal ranks pooled across folds. That
is what makes ~69 positives testable: the paired comparison then has n = all
positives rather than n = one held-out split, which is where L2's 215 came from.
"""

from __future__ import annotations

import argparse
import json
import random
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

HERE = Path(__file__).parent
WILD = {"broad_food", "unclear", "", None}


def d(s):
    try:
        return date.fromisoformat(str(s)[:10])
    except Exception:
        return None


def hardness(r, c):
    same_c = r["commodity"] == c["commodity"]
    compat = same_c or r["commodity"] in WILD or c["commodity"] in WILD
    same_l = r["district"] == c["district"] and r["district"] != "_other_"
    same_s = r["stage"] == c["stage"]
    lag = (r["date"] - c["date"]).days
    rec = max(0.0, 2.0 - min(lag, 730) / 365.0)
    return 4.0 * same_c + 2.0 * compat + 1.5 * same_l + 0.5 * same_s + rec


# ---- baselines: each returns a score per candidate, higher ranks first -------
def b_random(r, cands, rng):
    return [rng.random() for _ in cands]


def b_recency(r, cands, rng):
    return [-(r["date"] - c["date"]).days for c in cands]


def b_commodity(r, cands, rng):
    return [(2.0 if r["commodity"] == c["commodity"] else 0.0)
            - (r["date"] - c["date"]).days / 1000.0 for c in cands]


def b_hardness(r, cands, rng):
    return [hardness(r, c) for c in cands]


BASELINES = {"random": b_random, "recency": b_recency,
             "commodity": b_commodity, "hardness": b_hardness}


def reciprocal_rank(scores, gold_ix):
    """1/rank of the gold candidate; ties broken pessimistically."""
    g = scores[gold_ix]
    better = sum(1 for i, s in enumerate(scores) if s > g)
    tied = sum(1 for i, s in enumerate(scores) if s == g and i != gold_ix)
    return 1.0 / (better + tied / 2.0 + 1.0)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--simulate", type=float, default=None,
                    help="fabricate labels at this positive rate to exercise the harness")
    ap.add_argument("--simulate-mode", choices=("random", "hardest"), default="random",
                    help="random: labels uncorrelated with the heuristics (negative control). "
                         "hardest: the gold IS the hardness-maximal candidate, the degenerate "
                         "worst case -- the L0 check must FAIL on this or it is not a check.")
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=20260829)
    args = ap.parse_args()

    import scope_candidates as S

    evs = S.evs
    by_id = {e["event_id"]: e for e in evs}
    index = json.loads((HERE / "judge-index.json").read_text(encoding="utf-8"))

    groups = []
    for batch, specs in index.items():
        for g in specs:
            r = by_id.get(g["group_id"])
            cands = [by_id[c] for c in g["candidate_ids"] if c in by_id]
            if r and len(cands) >= 2:            # a ranking needs >=2 candidates
                groups.append({"response": r, "candidates": cands, "batch": batch})

    rng = random.Random(args.seed)
    simulated = args.simulate is not None
    if simulated:
        gold = {}
        for g in groups:
            if rng.random() < args.simulate:
                pick = (max(g["candidates"], key=lambda c: hardness(g["response"], c))
                        if args.simulate_mode == "hardest" else rng.choice(g["candidates"]))
                gold[g["response"]["event_id"]] = pick["event_id"]
    else:
        ef = HERE / "xdoc-edges.json"
        if not ef.exists():
            raise SystemExit("no xdoc-edges.json -- run ingest_judgments.py first, "
                             "or pass --simulate 0.15 to exercise the harness")
        gold = {}
        for e in json.loads(ef.read_text(encoding="utf-8")):
            gold.setdefault(e["src_id"], e["dst_id"])

    labelled = [g for g in groups
                if g["response"]["event_id"] in gold
                and gold[g["response"]["event_id"]] in {c["event_id"] for c in g["candidates"]}]
    print("rankable groups %d   labelled %d   %s"
          % (len(groups), len(labelled),
             ("SIMULATED (%s)" % args.simulate_mode) if simulated else "real judgments"))
    if not labelled:
        raise SystemExit("no labelled rankable groups")

    # temporal folds by response date
    labelled.sort(key=lambda g: g["response"]["date"])
    for i, g in enumerate(labelled):
        g["fold"] = i * args.folds // len(labelled)

    sizes = [len(g["candidates"]) for g in labelled]
    print("candidates per instance: median %d  mean %.1f  max %d"
          % (sorted(sizes)[len(sizes) // 2], sum(sizes) / len(sizes), max(sizes)))

    per_instance = {}
    for name, fn in BASELINES.items():
        rr = []
        brng = random.Random(args.seed)
        for g in labelled:
            r = g["response"]
            gix = [c["event_id"] for c in g["candidates"]].index(gold[r["event_id"]])
            rr.append(reciprocal_rank(fn(r, g["candidates"], brng), gix))
        per_instance[name] = rr

    print("\n%-12s %7s %8s %8s" % ("baseline", "MRR", "Hits@1", "Hits@3"))
    summary = {}
    for name, rr in per_instance.items():
        mrr = sum(rr) / len(rr)
        h1 = sum(1 for x in rr if x == 1.0) / len(rr)
        h3 = sum(1 for x in rr if x >= 1 / 3) / len(rr)
        summary[name] = {"mrr": round(mrr, 4), "hits1": round(h1, 4), "hits3": round(h3, 4)}
        print("%-12s %7.3f %8.3f %8.3f" % (name, mrr, h1, h3))

    strongest = max(summary, key=lambda k: summary[k]["mrr"])
    # Judge degeneracy on the STRONGEST heuristic, not just the selection function.
    # Checking only `hardness` would have passed a task that plain recency solves,
    # which is the same mistake in a different costume.
    degenerate = summary[strongest]["mrr"] >= 0.90 or summary[strongest]["hits1"] >= 0.85
    near = (not degenerate) and summary[strongest]["mrr"] >= 0.75
    print("\nstrongest heuristic : %s (MRR %.3f)" % (strongest, summary[strongest]["mrr"]))
    print("L0 degeneracy       : %s"
          % ("FAIL -- a trivial heuristic already solves the task" if degenerate else
             "pass, but NARROW -- %s alone reaches MRR %.3f" % (strongest, summary[strongest]["mrr"])
             if near else "pass -- clear headroom above every heuristic"))
    print("model must beat     : MRR %.3f" % summary[strongest]["mrr"])

    report = {"simulated": simulated, "simulate_rate": args.simulate,
              "simulate_mode": args.simulate_mode if simulated else None,
              "rankable_groups": len(groups), "labelled_instances": len(labelled),
              "folds": args.folds,
              "candidates_per_instance": {"median": sorted(sizes)[len(sizes) // 2],
                                          "mean": round(sum(sizes) / len(sizes), 2),
                                          "max": max(sizes)},
              "baselines": summary, "strongest_heuristic": strongest,
              "L0_degenerate": degenerate, "L0_narrow": near,
              "target_mrr_to_beat": summary[strongest]["mrr"],
              "fold_sizes": dict(Counter(g["fold"] for g in labelled))}
    (HERE / ("task-report-simulated.json" if simulated else "task-report.json")).write_text(
        json.dumps(report, indent=2), encoding="utf-8")

    if simulated:
        print("\nsimulated run: task file NOT written")
    else:
        task = [{"response_id": g["response"]["event_id"], "fold": g["fold"],
                 "response_date": str(g["response"]["date"]),
                 "gold": gold[g["response"]["event_id"]],
                 "candidates": [c["event_id"] for c in g["candidates"]]} for g in labelled]
        (HERE / "xdoc-task.json").write_text(json.dumps(task, indent=1), encoding="utf-8")
        print("\nwrote xdoc-task.json (%d instances, %d folds)" % (len(task), args.folds))


if __name__ == "__main__":
    main()
