"""Agreement between judging variants A (best-match) and B (necessity).

Reported per group AND per pair. Per-group agreement flatters a task where most
groups are empty, so the pair-level figure over the union of proposed positives
is the one that matters -- it is the coreference round's 9-vs-1 collapse expressed
as a number.
"""
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).parent


def load(d):
    out = {}
    for f in sorted((HERE / d).glob("judge-*.json")):
        for r in json.loads(f.read_text(encoding="utf-8")):
            out[r["group_id"]] = r
    return out


A, B = load("judgments"), load("judgments-variant-b")
gids = sorted(set(A) & set(B))
print(f"groups judged by both: {len(gids)}\n")

both = a_only = b_only = neither = 0
pair_both = pair_a = pair_b = 0
flips = []
for g in gids:
    sa = set(A[g].get("responds_to") or [])
    sb = set(B[g].get("responds_to") or [])
    pair_both += len(sa & sb); pair_a += len(sa - sb); pair_b += len(sb - sa)
    if sa and sb:
        both += 1
        if sa != sb:
            flips.append((g, "same group, different target", sorted(sa), sorted(sb)))
    elif sa:
        a_only += 1; flips.append((g, "A positive, B rejected", sorted(sa), []))
    elif sb:
        b_only += 1; flips.append((g, "B positive, A rejected", [], sorted(sb)))
    else:
        neither += 1

n = len(gids)
obs = (both + neither) / n
pa = (both + a_only) / n
pb = (both + b_only) / n
exp = pa * pb + (1 - pa) * (1 - pb)
kappa = (obs - exp) / (1 - exp) if exp < 1 else None

print(f"{'':22s} {'A':>4s} {'B':>4s}")
print(f"{'groups with positive':22s} {both+a_only:>4d} {both+b_only:>4d}")
print(f"{'positive rate':22s} {(both+a_only)/n:>4.0%} {(both+b_only)/n:>4.0%}\n")
print(f"agree positive   {both:3d}")
print(f"agree negative   {neither:3d}")
print(f"A only           {a_only:3d}")
print(f"B only           {b_only:3d}")
print(f"group agreement  {obs:.0%}   Cohen's kappa {kappa:.3f}\n")
print(f"pair level: both {pair_both}   A only {pair_a}   B only {pair_b}   "
      f"Jaccard {pair_both/max(1,pair_both+pair_a+pair_b):.3f}")
print(f"survival of A's positives under B: {pair_both}/{pair_both+pair_a} "
      f"({pair_both/max(1,pair_both+pair_a):.0%})")
print("\ndisagreements:")
for g, why, sa, sb in flips:
    print(f"  {g}")
    print(f"      {why}")
    print(f"      A: {sa or 'none'}   reason: {A[g]['reasoning'][:96]}")
    print(f"      B: {sb or 'none'}   reason: {B[g]['reasoning'][:96]}")

json.dump({"groups": n, "agree_positive": both, "agree_negative": neither,
           "A_only": a_only, "B_only": b_only,
           "group_agreement": round(obs, 4), "cohens_kappa": round(kappa, 4),
           "pair_jaccard": round(pair_both / max(1, pair_both + pair_a + pair_b), 4),
           "A_positive_survival_under_B": round(pair_both / max(1, pair_both + pair_a), 4),
           "rate_A": round((both + a_only) / n, 4), "rate_B": round((both + b_only) / n, 4)},
          open(HERE / "variant-agreement.json", "w"), indent=2)
