"""Would cross-document positives actually clear L1? Simulate before judging.

The 24 judging batches are only worth running if the positives they produce move
the gate. This injects hypothetical cross-document positives into the D6
computation at a range of positive rates and reports what L1 would read.

Two selection regimes, because which candidates turn out to be positive matters
more than how many:

  optimistic   positives drawn uniformly at random from each group's candidates
  pessimistic  the single hardest candidate in each group is the positive

Pessimistic is the realistic worry: a true response probably IS the nearest,
best-matching disruption, which is exactly the candidate that maxes the hardness
function -- the same trap the intra-article positives fall into. If L1 fails
under pessimistic selection, judging cannot rescue it and the blocking must
change instead.

Hardness function and competitor pool are copied from viability_check.py D6 so
the numbers are directly comparable.
"""

from __future__ import annotations

import json
import os
import random
from collections import defaultdict
from pathlib import Path

import scope_candidates as S

WILD = S.WILD
MAX_LAG = 180
SEED = 20260829

evs = S.evs
resp = [e for e in evs if not e["is_dis"] and e["date"]]
dis = [e for e in evs if e["is_dis"] and e["date"]]


def hardness(r, c):
    same_c = r["commodity"] == c["commodity"]
    compat = same_c or r["commodity"] in WILD or c["commodity"] in WILD
    same_l = r["district"] == c["district"] and r["district"] != "_other_"
    same_s = r["stage"] == c["stage"]
    lag = (r["date"] - c["date"]).days
    rec = max(0.0, 2.0 - min(lag, 730) / 365.0)
    return 4.0 * same_c + 2.0 * compat + 1.5 * same_l + 0.5 * same_s + rec


def competitors(r, positive):
    """Same pool D6 uses: every dated cross-article disruption before r."""
    h = hardness(r, positive)
    return sum(1 for c in dis
               if c is not positive and c["date"] <= r["date"] and c["article"] != r["article"]
               and hardness(r, c) >= h)


# ---- the existing intra-article positives, recomputed the same way ----------
by_article = defaultdict(list)
for e in evs:
    by_article[e["article"]].append(e)

def load_relations():
    out = []
    def take(a):
        aid = a.get("candidate_id")
        slot = {e.get("event_slot"): (e.get("event_id") or f"{aid}:llm:event:{e.get('event_slot')}")
                for e in a.get("events") or []}
        for rel in a.get("relations") or []:
            if (rel.get("predicate") or rel.get("relation")) != "respondsTo":
                continue
            out.append((rel.get("subject_event_id") or slot.get(rel.get("subject_event_slot")),
                        rel.get("object_event_or_policy_id") or slot.get(rel.get("object_event_slot"))))
    for a in json.loads(S.PILOT.read_text(encoding="utf-8"))["annotations"]:
        take(a)
    for p in sorted(S.CKPT.glob("ann_*.json")):
        try:
            c = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if c.get("status") == "complete" and c.get("annotation"):
            take(c["annotation"])
    if os.environ.get("TKG_WITH_CHAT"):
        for p in sorted(S.CHAT.glob("ann_*.json")):
            try:
                c = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            if c.get("annotation"):
                take(c["annotation"])
    return out


by_id = {e["event_id"]: e for e in evs}
base = []
for s, o in load_relations():
    r_, d_ = by_id.get(s), by_id.get(o)
    if r_ and d_ and r_["date"] and d_["date"] and d_["date"] <= r_["date"]:
        base.append(competitors(r_, d_))
print(f"existing intra-article positives scored : {len(base)}")
print(f"   strictly hardest {sum(1 for x in base if x == 0)/len(base):.0%}   "
      f"median competitors {sorted(base)[len(base)//2]}\n")

# ---- candidate groups -------------------------------------------------------
bd = defaultdict(list)
for x in dis:
    bd[x["district"]].append(x)
groups = []
for r in resp:
    if r["district"] == "_other_":
        continue
    c = [x for x in bd.get(r["district"], [])
         if x["article"] != r["article"] and 0 <= (r["date"] - x["date"]).days <= MAX_LAG]
    if c:
        groups.append((r, c[:10]))
print(f"candidate groups {len(groups)}\n")

print(f"{'regime':12s} {'rate':>5s} {'positives':10s} {'n':>6s} "
      f"{'strictly hardest':>17s} {'median comp':>12s}  gates")
rows = []
for regime in ("optimistic", "pessimistic"):
    for rate in (0.05, 0.10, 0.15, 0.25):
        rng = random.Random(SEED)
        picked = []
        for r, cands in groups:
            if rng.random() > rate:          # rate = P(this group contains a true positive)
                continue
            pos = (max(cands, key=lambda c: hardness(r, c)) if regime == "pessimistic"
                   else rng.choice(cands))
            picked.append(competitors(r, pos))
        for mode, allc in (("pooled", base + picked), ("xdoc-only", picked)):
            if not allc:
                continue
            sh = sum(1 for x in allc if x == 0) / len(allc)
            med = sorted(allc)[len(allc) // 2]
            l1 = sh < 0.80 and med >= 1
            l2 = len(allc) >= 215
            print(f"{regime:12s} {rate:5.0%} {mode:10s} {len(allc):>6d} "
                  f"{sh:>16.0%} {med:>12d}  L1 {'PASS' if l1 else 'fail'}  "
                  f"L2 {'PASS' if l2 else 'fail'}")
            rows.append({"regime": regime, "rate": rate, "mode": mode,
                         "new_positives": len(picked), "total": len(allc),
                         "strictly_hardest": round(sh, 4), "median_competitors": med,
                         "L1": l1, "L2": l2})

Path("dry-run-l1.json").write_text(json.dumps(
    {"gate": "strictly_hardest < 0.80 AND median_competitors >= 1",
     "baseline_intra_article": {"n": len(base),
                                "strictly_hardest": round(sum(1 for x in base if x == 0)/len(base), 4),
                                "median": sorted(base)[len(base)//2]},
     "simulations": rows}, indent=2), encoding="utf-8")
print("\nwrote dry-run-l1.json")
