"""Compact form of each judge batch: same information, ~half the tokens."""
import re
from pathlib import Path

HERE = Path(__file__).parent
OUT = HERE / "digests"; OUT.mkdir(exist_ok=True)
EV = 165

for f in sorted((HERE / "judge-batches").glob("judge-*.txt")):
    txt = f.read_text(encoding="utf-8")
    lines = []
    for block in txt.split("===== GROUP ")[1:]:
        gid = re.search(r"group_id: (\S+)", block).group(1)
        def field(name, seg):
            m = re.search(rf"{name}\s*: (.*)", seg)
            return (m.group(1).strip() if m else "")
        head, *rest = re.split(r"CANDIDATE DISRUPTIONS \(\d+\):", block)
        ev = field("evidence", head)[:EV]
        lines.append(f"G {gid}")
        lines.append(f"R {field('subtype', head)} | {field('date', head)} | "
                     f"{field('district', head)} | {field('commodity', head)} | {ev}")
        if rest:
            for c in re.split(r"\n\s+\[\d+\] lag ", rest[0])[1:]:
                lag = c.split("d\n")[0].strip()
                cid = re.search(r"id=(\S+)", c)
                if not cid:
                    continue
                lines.append(f"  c {cid.group(1)} | {field('subtype', c)} | {field('date', c)} | "
                             f"lag{lag}d | {field('commodity', c)} | {field('evidence', c)[:EV]}")
        lines.append("")
    (OUT / (f.stem + ".txt")).write_text("\n".join(lines), encoding="utf-8")

sizes = [(p.name, p.stat().st_size) for p in sorted(OUT.glob("*.txt"))]
orig = sum(p.stat().st_size for p in (HERE / "judge-batches").glob("*.txt"))
print(f"{len(sizes)} digests   {sum(s for _, s in sizes):,} bytes  (from {orig:,})")
