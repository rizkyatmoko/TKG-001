"""Size the cross-document respondsTo candidate pool under several blocking rules.

Why. Every respondsTo edge the extractor emits links two event slots inside one
article, so 100% of positives are intra-article. That is what breaks L1: an
intra-article positive almost always shares commodity, district and a small lag
with its disruption, which maxes the hardness function, and no cross-article
candidate can match it. Cross-document positives would sit at ordinary hardness
and let competitors reach them.

Getting them needs candidate generation + judging. This script only sizes the
generation step, so the judging budget is a measured number rather than a guess.

Read-only.
"""

from __future__ import annotations

import json
import os
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(r"C:\Users\HP\Documents\ChatGPT\News TKG")
PILOT = ROOT / "data" / "annotation" / "llm-silver-pilot-v2.json"
CKPT = ROOT / ".artifacts" / "extraction-expansion-v3" / "qwen8b-verbose-primary"
CHAT = Path(__file__).parent.parent / "news-tkg-chat" / "checkpoints-chat"

DISRUPTION = {"SupplyShortage", "ProductionDisruption", "DistributionDisruption",
              "WeatherDisruption", "DisasterEvent", "PestDiseaseEvent", "FoodSafetyIncident"}
WILD = {"broad_food", "unclear", "", None}
DISTRICTS = ["surabaya", "bangkalan", "banyuwangi", "batu", "blitar", "bojonegoro",
             "bondowoso", "gresik", "jember", "jombang", "kediri", "lamongan", "lumajang",
             "madiun", "magetan", "malang", "mojokerto", "nganjuk", "ngawi", "pacitan",
             "pamekasan", "pasuruan", "ponorogo", "probolinggo", "sampang", "sidoarjo",
             "situbondo", "sumenep", "trenggalek", "tuban", "tulungagung", "madura"]


def d(s):
    try:
        return date.fromisoformat(str(s)[:10])
    except Exception:
        return None


def district(loc: str) -> str:
    low = (loc or "").lower()
    for x in DISTRICTS:
        if x in low:
            return x
    return "_other_"


def load():
    arts = [dict(a, _s="pilot") for a in
            json.loads(PILOT.read_text(encoding="utf-8"))["annotations"]]
    for p in sorted(CKPT.glob("ann_*.json")):
        try:
            c = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        if c.get("status") == "complete" and c.get("annotation"):
            arts.append(dict(c["annotation"], _s="expansion"))
    if os.environ.get("TKG_WITH_CHAT"):
        for p in sorted(CHAT.glob("ann_*.json")):
            try:
                c = json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                continue
            if c.get("annotation"):
                arts.append(dict(c["annotation"], _s="chat"))
    evs = []
    for a in arts:
        aid = a.get("candidate_id")
        for e in a.get("events") or []:
            st = e.get("event_subtype")
            evs.append({
                "event_id": e.get("event_id") or f"{aid}:llm:event:{e.get('event_slot')}",
                "article": aid, "subtype": st, "is_dis": st in DISRUPTION,
                "date": d(e.get("event_date")), "commodity": e.get("commodity"),
                "district": district(e.get("location")), "stage": e.get("food_system_stage"),
                "publisher": (a.get("source") or "").split("_")[0], "src": a["_s"],
            })
    return evs


evs = load()
resp = [e for e in evs if not e["is_dis"] and e["date"]]
dis = [e for e in evs if e["is_dis"] and e["date"]]
print(f"events {len(evs)}   responses {len(resp)}   disruptions {len(dis)}")
print(f"naive all-pairs: {len(resp) * len(dis):,}\n")

by_district = defaultdict(list)
for x in dis:
    by_district[x["district"]].append(x)


def compat(a, b):
    return a["commodity"] == b["commodity"] or a["commodity"] in WILD or b["commodity"] in WILD


RULES = {
    "A same district, lag 0-180d":
        lambda r, c: r["district"] == c["district"] and r["district"] != "_other_"
                     and 0 <= (r["date"] - c["date"]).days <= 180,
    "B same district + compatible commodity, lag 0-180d":
        lambda r, c: r["district"] == c["district"] and r["district"] != "_other_"
                     and compat(r, c) and 0 <= (r["date"] - c["date"]).days <= 180,
    "C same district + SAME commodity, lag 0-180d":
        lambda r, c: r["district"] == c["district"] and r["district"] != "_other_"
                     and r["commodity"] == c["commodity"] and 0 <= (r["date"] - c["date"]).days <= 180,
    "D same district + compatible commodity, lag 0-90d":
        lambda r, c: r["district"] == c["district"] and r["district"] != "_other_"
                     and compat(r, c) and 0 <= (r["date"] - c["date"]).days <= 90,
    "E compatible commodity only, lag 0-60d (province-wide)":
        lambda r, c: compat(r, c) and 0 <= (r["date"] - c["date"]).days <= 60,
}

print(f"{'blocking rule':52s} {'pairs':>8s} {'resp w/ >=1':>11s} {'med/resp':>9s} {'p90':>5s}")
results = {}
for name, ok in RULES.items():
    pool, per = 0, []
    for r in resp:
        cands = [c for c in (by_district.get(r["district"], []) if name != "E" else dis)
                 if c["article"] != r["article"] and ok(r, c)]
        per.append(len(cands))
        pool += len(cands)
    nz = [x for x in per if x]
    per_s = sorted(per)
    results[name] = {"pairs": pool, "responses_with_candidates": len(nz),
                     "median_per_response": per_s[len(per_s) // 2] if per_s else 0,
                     "p90_per_response": per_s[int(len(per_s) * 0.9)] if per_s else 0}
    print(f"{name:52s} {pool:>8,} {len(nz):>11} {results[name]['median_per_response']:>9} "
          f"{results[name]['p90_per_response']:>5}")

Path("candidate-scope.json").write_text(json.dumps({
    "events": len(evs), "responses": len(resp), "disruptions": len(dis),
    "with_chat": bool(os.environ.get("TKG_WITH_CHAT")), "rules": results,
}, indent=2), encoding="utf-8")
print("\nwrote candidate-scope.json")
