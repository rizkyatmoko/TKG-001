# Variant B — necessity framing. For measuring judge reliability, not for bulk judging.

Paste this once, then one `judge-batches/judge-XXX.txt` per turn. JSON only.

---

Variant A asks "which candidate does this response respond to?" — a question that
presupposes one of them does, and rewards picking the best of a list. This variant
asks a different question about the same pairs, so agreement between the two
measures something rather than measuring a rephrasing.

You are testing **necessity**, one pair at a time.

For each candidate, independently of the others, ask:

> Would the response, **as its evidence describes it**, have been reported in
> those terms if this disruption had not occurred?

If the answer is *yes, it could have been reported exactly this way anyway* — the
candidate is **not** the cause. Only when the response's own wording is
unexplainable without that specific occurrence does the pair count.

There is no "best candidate". Judge every pair on its own. It is entirely normal
for a group to have no qualifying pair, and it is possible (though rare) for two
to qualify.

## Output

```json
[
  {
    "group_id": "ann_xxxx:llm:event:2",
    "responds_to": ["ann_yyyy:llm:event:1"],
    "probability_pct": 0,
    "basis": "explicit | same_incident | thematic | none",
    "reasoning": "one short sentence"
  }
]
```

`basis` is assigned **after** the necessity test, describing what made the pair
survive it:

| value | survives when |
|---|---|
| `explicit` | the response's evidence names the disruption, its cause or its damage |
| `same_incident` | the response's wording presupposes one occurrence that the candidate is plainly a report of |
| `thematic` | the pair is topically related but the response reads the same without it — **not** a positive |
| `none` | no candidate survives |

## The three ways a pair fails necessity

1. **Generic beneficiary.** "aid for affected residents", "help for farmers",
   "steps to stabilise prices" — these read identically after any disruption of
   that kind. Shared district and a short lag do not make them specific.
2. **Standing activity.** Scheduled distributions, annual schemes, routine
   inspections, ceremonies, training, ongoing programmes. These would have been
   reported in the same terms in a year with no disruption at all.
3. **Episode, not occurrence.** A months-long outbreak, a long dry season, or a
   sustained price rise is reported many times. A response to the condition is
   not a response to any one of those reports. If the candidate is one report
   among several of a continuing situation, the pair fails.

Failure 3 is the one most likely to be missed. Check the lag: if the response
comes weeks or months after the candidate and the candidate describes a state
rather than an event, it is almost certainly an episode.

## Calibration

`probability_pct` is the probability that the necessity test genuinely holds —
0 when nothing survives, otherwise 1–100. Being near the line is normal; use the
middle of the range and do not cluster everything at 90+.
