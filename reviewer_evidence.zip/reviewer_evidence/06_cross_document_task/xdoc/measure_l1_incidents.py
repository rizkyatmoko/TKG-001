"""Layer-1 benchmark integrity at incident level, for both positive sets.

The published L1 figures (intra-article 61% strictly hardest, median 0
competitors; cross-document 29%, median 3) counted competitors over raw
disruption MENTIONS. Another report of the gold incident carries the gold's own
attributes, so it scores at the gold's hardness and is counted as a competitor --
inflating the very number the gate reads.

Both positive sets are measured twice with one function:
  raw        competitors are mentions  (must reproduce the cross-document 29% / 3)
  incident   competitors are coreference-canonical incidents, never the gold's own
The competitor rule is otherwise the D6 rule: dated no later than the response,
not reported in the response's article, hardness at or above the positive's.

Writes l1-incidents.json. Read-only otherwise.
"""
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).parent
os.environ.setdefault("TKG_WITH_CHAT", "1")
sys.path.insert(0, str(HERE))
import scope_candidates as S  # noqa: E402  (prints its own table)

WILD = S.WILD


def hardness(r, c):  # identical to viability_check D6 and eval_xdoc
    same_c = r["commodity"] == c["commodity"]
    compat = same_c or r["commodity"] in WILD or c["commodity"] in WILD
    same_l = r["district"] == c["district"] and r["district"] != "_other_"
    same_s = r["stage"] == c["stage"]
    lag = (r["date"] - c["date"]).days
    rec = max(0.0, 2.0 - min(lag, 730) / 365.0)
    return 4.0 * same_c + 2.0 * compat + 1.5 * same_l + 0.5 * same_s + rec


evs = S.evs
by_id = {e["event_id"]: e for e in evs}
dis_all = [e for e in evs if e["is_dis"] and e["date"]]
canon_full = {}
for c in json.loads((HERE.parent / "news-tkg-gnn" / "coref-with-chat.json")
                    .read_text(encoding="utf-8")).get("cluster_members", []):
    for m in c["members"]:
        canon_full[m] = c["canonical"]


def incidents_for(canon):
    members = defaultdict(list)
    for e in dis_all:
        members[canon.get(e["event_id"], e["event_id"])].append(e)
    out = {}
    for k, ms in members.items():
        rec = dict(by_id[k]) if k in by_id else dict(ms[0])
        rec["event_id"] = k
        rec["date"] = min(m["date"] for m in ms)
        rec["articles"] = {m["article"] for m in ms}
        out[k] = rec
    return out


# ---- the two positive sets ----------------------------------------------------
xdoc = [(e["src_id"], e["dst_id"])
        for e in json.loads((HERE / "xdoc-edges.json").read_text(encoding="utf-8"))]


def take(a, out):
    aid = a.get("candidate_id")
    slot = {e.get("event_slot"): (e.get("event_id") or f"{aid}:llm:event:{e.get('event_slot')}")
            for e in a.get("events") or []}
    for rel in a.get("relations") or []:
        if (rel.get("predicate") or rel.get("relation")) != "respondsTo":
            continue
        out.append((rel.get("subject_event_id") or slot.get(rel.get("subject_event_slot")),
                    rel.get("object_event_or_policy_id") or slot.get(rel.get("object_event_slot"))))


intra = []
for a in json.loads(S.PILOT.read_text(encoding="utf-8"))["annotations"]:
    take(a, intra)
for f_ in sorted(S.CKPT.glob("ann_*.json")):
    try:
        c = json.loads(f_.read_text(encoding="utf-8"))
    except Exception:
        continue
    if c.get("status") == "complete" and c.get("annotation"):
        take(c["annotation"], intra)
for f_ in sorted(S.CHAT.glob("ann_*.json")):
    try:
        c = json.loads(f_.read_text(encoding="utf-8"))
    except Exception:
        continue
    if c.get("annotation"):
        take(c["annotation"], intra)


def measure(pairs, canon):
    inc = incidents_for(canon)
    comps = []
    for s, o in pairs:
        r, d0 = by_id.get(s), by_id.get(o)
        if not r or not d0 or not r["date"] or not d0["date"] or d0["date"] > r["date"]:
            continue
        gk = canon.get(o, o)
        g = inc.get(gk) or dict(d0, articles={d0["article"]})
        h = hardness(r, g)
        comps.append(sum(1 for c in inc.values()
                         if c["event_id"] != gk and c["date"] <= r["date"]
                         and r["article"] not in c["articles"] and hardness(r, c) >= h))
    comps.sort()
    n = len(comps)
    sh = sum(1 for x in comps if x == 0) / n
    med = comps[n // 2]
    return {"pairs": n, "strictly_hardest": round(sh, 4), "median_competitors": med,
            "share_with_ge_1": round(sum(1 for x in comps if x >= 1) / n, 4),
            "L1_pass": bool(sh < 0.80 and med >= 1), "competitors_sorted": comps}


report = {}
print("\n" + "=" * 72)
print(f"{'positive set':16s} {'protocol':9s} {'pairs':>5s} {'strictly hardest':>17s} "
      f"{'median comp':>11s}  L1")
for name, pairs in (("intra-article", intra), ("cross-document", xdoc)):
    for proto, canon in (("raw", {}), ("incident", canon_full)):
        m = measure(pairs, canon)
        report[f"{name}|{proto}"] = m
        print(f"{name:16s} {proto:9s} {m['pairs']:5d} {m['strictly_hardest']:16.0%} "
              f"{m['median_competitors']:11d}  {'PASS' if m['L1_pass'] else 'fail'}")
print("\ncross-document competitors, incident level:",
      report["cross-document|incident"]["competitors_sorted"])
(HERE / "l1-incidents.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print("wrote l1-incidents.json")
