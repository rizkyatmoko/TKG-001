"""Build JISEBI_manuscript.docx on the journal's own Word template (tpl/).

Uses the template's styles (JISEBITitle, JISEBIAuthorName, JISEBIHeading1/2 which auto-number
I./A., Caption, TableTitle, equation0, Text, references0 which auto-numbers [n]), its abstract
box, its corresponding-author footnote, headers and footer. Page size is A4 as the written
guideline requires (the template file itself is US Letter).

Equations are native Word equations (OMML), as the template asks for an equation editor.
Body text is converted to American English; reference entries are left untouched.
"""
import re
import shutil
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import jisebi_content as J  # noqa: E402

TPL = HERE / "tpl"
BUILD = HERE / "build"
OUT = HERE / "JISEBI_manuscript.docx"
TEXT_W = 11906 - 2 * 1440          # A4 width minus 1-inch margins, twips
CELL_M = 108

try:
    from PIL import ImageFont
    F_REG = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 160)     # 8 pt -> twips
    F_BLD = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 160)
except Exception:
    F_REG = F_BLD = None

# ------------------------------------------------------------------ American English
AME = {
    "materialisation": "materialization", "Materialised": "Materialized",
    "materialised": "materialized", "Normalised": "Normalized", "normalised": "normalized",
    "normalises": "normalizes", "normalising": "normalizing", "normalise": "normalize",
    "analogue": "analog", "anonymisation": "anonymization", "anonymised": "anonymized",
    "artefacts": "artifacts", "artefact": "artifact", "generalises": "generalizes",
    "generalise": "generalize", "judgements": "judgments", "Judgements": "Judgments",
    "judgement": "judgment", "maximises": "maximizes", "maximise": "maximize",
    "memorisation": "memorization", "Modelling": "Modeling", "modelling": "modeling",
    "organised": "organized", "serialised": "serialized", "standardised": "standardized",
    "standardise": "standardize", "Neighbourhoods": "Neighborhoods",
    "neighbourhoods": "neighborhoods", "neighbourhood": "neighborhood", "behaviour": "behavior",
    "labelled": "labeled", "favour": "favor", "centre": "center", "amongst": "among",
    "whilst": "while", "learnt": "learned",
}
AME_RX = re.compile(r"\b(" + "|".join(sorted(AME, key=len, reverse=True)) + r")\b")
BRITISH = re.compile(r"\b\w+(?:isation|isations|ised|ises|ising|yse|ysed|efact|efacts|ourhood)\b"
                     r"|\b(?:judgement|modelling|behaviour|labelled|centre|analogue|whilst|amongst)\b")
BRIT_OK = {"exercised", "raising", "noise", "otherwise", "promise", "premise", "precise", "rise"}


def ame(s):
    return AME_RX.sub(lambda m: AME[m.group(1)], s)


ROMAN = {"I": 1, "II": 2, "III": 3, "IV": 4, "V": 5, "VI": 6, "VII": 7}


def remap_refs(s, sections=True):
    s = re.sub(r"\bTable (VII|VI|IV|V|III|II|I)\b", lambda m: f"Table {ROMAN[m.group(1)]}", s)
    if sections:
        for old in sorted(J.SECTION_MAP, key=len, reverse=True):
            s = re.sub(re.escape(old) + r"(?![.\w])", J.SECTION_MAP[old], s)
    return s


# ------------------------------------------------------------------ runs and paragraphs
def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def run(text, b=False, i=False, vert=None, sz=None, hl=False, font=None):
    rpr = ""
    if font:
        rpr += f'<w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:cs="{font}"/>'
    if b:
        rpr += "<w:b/><w:bCs/>"
    if i:
        rpr += "<w:i/><w:iCs/>"
    if hl:
        rpr += '<w:highlight w:val="yellow"/>'
    if sz:
        rpr += f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>'
    if vert:
        rpr += f'<w:vertAlign w:val="{vert}"/>'
    rpr = f"<w:rPr>{rpr}</w:rPr>" if rpr else ""
    parts = text.split("\t")
    body = "".join(("<w:tab/>" if k else "") + (f'<w:t xml:space="preserve">{esc(p)}</w:t>' if p else "")
                   for k, p in enumerate(parts))
    return f"<w:r>{rpr}{body}</w:r>" if body else ""


def para(runs, style=None, ppr_extra="", mark_sz=None):
    ppr = (f'<w:pStyle w:val="{style}"/>' if style else "") + ppr_extra
    if mark_sz:
        ppr += f'<w:rPr><w:sz w:val="{mark_sz}"/><w:szCs w:val="{mark_sz}"/></w:rPr>'
    return f"<w:p><w:pPr>{ppr}</w:pPr>{runs}</w:p>"


CITE = {}
TOKEN = re.compile(r"\*([^*]+)\*|\^\{([^}]*)\}|_\{([^}]*)\}|\[\[([A-Za-z0-9_]+)\]\]|\u00ab([^\u00bb]*)\u00bb")


def inline(text, sz=None, base_i=False):
    out, pos = "", 0
    for m in TOKEN.finditer(text):
        if m.start() > pos:
            out += run(text[pos:m.start()], i=base_i, sz=sz)
        ital, sup, sub, key, hl = m.groups()
        if ital is not None:
            out += run(ital, i=not base_i, sz=sz)
        elif sup is not None:
            out += run(sup, i=base_i, sz=sz, vert="superscript")
        elif sub is not None:
            out += run(sub, i=base_i, sz=sz, vert="subscript")
        elif key is not None:
            CITE.setdefault(key, len(CITE) + 1)
            out += run(f"[{CITE[key]}]", i=base_i, sz=sz)
        else:
            out += run(hl, i=base_i, sz=sz, hl=True)
        pos = m.end()
    if pos < len(text):
        out += run(text[pos:], i=base_i, sz=sz)
    return out


def body_text(s, sections=True):
    return ame(remap_refs(s, sections))


# ------------------------------------------------------------------ OMML equations
FUNCS = ("argmax", "ReLU", "max", "med", "Pr")
BELOW = ("\u2211", "argmax", "max")


def parse(s):
    out, buf, i = [], "", 0
    while i < len(s):
        c = s[i]
        if c in "_^" and i + 1 < len(s) and s[i + 1] == "{":
            j, depth = i + 2, 1
            while depth:
                depth += {"{": 1, "}": -1}.get(s[j], 0)
                j += 1
            inner = parse(s[i + 2:j - 1])
            if not buf and out and out[-1][0] == "s":
                _, base, sub, sup = out.pop()
            else:
                m = re.search(r"(argmax|ReLU|max|med|Pr)$", buf)
                base_txt = m.group(1) if m else buf[-1]
                buf = buf[:len(buf) - len(base_txt)]
                if buf:
                    out.append(("t", buf))
                    buf = ""
                base, sub, sup = base_txt, None, None
            if c == "_":
                sub = inner
            else:
                sup = inner
            out.append(("s", base, sub, sup))
            i = j
        else:
            buf += c
            i += 1
    if buf:
        out.append(("t", buf))
    return out


def m_run(txt, plain=False):
    sty = '<m:rPr><m:sty m:val="p"/></m:rPr>' if plain else ""
    return (f'<m:r>{sty}<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/></w:rPr>'
            f'<m:t xml:space="preserve">{esc(txt)}</m:t></m:r>')


def m_text(t):
    out = ""
    for piece in re.split(r"(argmax|ReLU|max|med|Pr)", t):
        if piece:
            out += m_run(piece, plain=piece in FUNCS)
    return out


def emit(nodes):
    out = ""
    for n in nodes:
        if n[0] == "t":
            out += m_text(n[1])
            continue
        _, base, sub, sup = n
        e = f"<m:e>{m_text(base)}</m:e>"
        if base in BELOW and sub is not None and sup is None:
            out += f"<m:limLow>{e}<m:lim>{emit(sub)}</m:lim></m:limLow>"
        elif sub is not None and sup is not None:
            out += f"<m:sSubSup>{e}<m:sub>{emit(sub)}</m:sub><m:sup>{emit(sup)}</m:sup></m:sSubSup>"
        elif sub is not None:
            out += f"<m:sSub>{e}<m:sub>{emit(sub)}</m:sub></m:sSub>"
        else:
            out += f"<m:sSup>{e}<m:sup>{emit(sup)}</m:sup></m:sSup>"
    return out


def equation(markup, n):
    tabs = ('<w:tabs><w:tab w:val="clear" w:pos="2520"/><w:tab w:val="clear" w:pos="5040"/>'
            f'<w:tab w:val="center" w:pos="{TEXT_W // 2}"/><w:tab w:val="right" w:pos="{TEXT_W}"/>'
            '</w:tabs><w:jc w:val="left"/>')
    return (f'<w:p><w:pPr><w:pStyle w:val="equation0"/>{tabs}</w:pPr>'
            + run("\t", font="Times New Roman") + "<m:oMath>" + emit(parse(markup)) + "</m:oMath>"
            + run(f"\t({n})", font="Times New Roman") + "</w:p>")


# ------------------------------------------------------------------ tables
def width_tw(s, bold=False):
    s = re.sub(r"[_^]\{([^}]*)\}", r"\1", s)
    if F_REG is None:
        return len(s) * 80
    return int((F_BLD if bold else F_REG).getlength(s))


def table(spec, n):
    header, rows = spec["header"], spec["rows"]
    if len(header) == 2 and len(rows) > 12:                  # two halves side by side
        half = (len(rows) + 1) // 2
        right = rows[half:] + [["", ""]] * (2 * half - len(rows))
        rows = [l + r for l, r in zip(rows[:half], right)]
        header = header + header
    ncol = len(header)
    nat = [max([width_tw(header[c], True)] + [width_tw(r[c]) for r in rows]) + 2 * CELL_M + 80
           for c in range(ncol)]
    total = sum(nat)
    widths = nat if total <= TEXT_W else [max(700, int(w * TEXT_W / total)) for w in nat]
    tw = sum(widths)
    numeric = [all(re.fullmatch(r"[\d.,%<>\s\u2212-]*|fail|pass|L\d(, L\d)?", r[c].strip() or "0")
                   for r in rows) for c in range(ncol)]

    def cell(txt, w, c, first=False, last=False):
        b = []
        if first:
            b += ['<w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>',
                  '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>']
        if last:
            b.append('<w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>')
        borders = f"<w:tcBorders>{''.join(b)}</w:tcBorders>" if b else ""
        indent = txt.startswith("    ")
        t = body_text(txt.strip())
        jc = "center" if numeric[c] and not first else ("left" if not numeric[c] else "center")
        ppr = (f'<w:ind w:left="{200 if indent else 0}" w:firstLine="0"/>'
               f'<w:spacing w:before="0" w:after="0"/><w:jc w:val="{jc}"/>')
        return (f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>{borders}<w:vAlign w:val="center"/>'
                f"</w:tcPr>{para(inline(t, sz=16), ppr_extra=ppr, mark_sz=16)}</w:tc>")

    x = [para(run(f"TABLE {n}"), "Caption", '<w:keepNext/><w:spacing w:before="240"/><w:jc w:val="center"/>'),
         para(inline(body_text(spec["caption"])), "TableTitle", "<w:keepNext/>"),
         f'<w:tbl><w:tblPr><w:tblW w:w="{tw}" w:type="dxa"/><w:jc w:val="center"/>'
         '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" '
         'w:noHBand="0" w:noVBand="1"/></w:tblPr><w:tblGrid>'
         + "".join(f'<w:gridCol w:w="{w}"/>' for w in widths) + "</w:tblGrid>"]
    x.append('<w:tr><w:trPr><w:tblHeader/><w:cantSplit/><w:jc w:val="center"/></w:trPr>'
             + "".join(cell(header[c], widths[c], c, first=True) for c in range(ncol)) + "</w:tr>")
    for k, r in enumerate(rows):
        x.append('<w:tr><w:trPr><w:cantSplit/><w:jc w:val="center"/></w:trPr>'
                 + "".join(cell(r[c], widths[c], c, last=(k == len(rows) - 1)) for c in range(ncol))
                 + "</w:tr>")
    x.append("</w:tbl>")
    x.append(para("", ppr_extra='<w:spacing w:before="0" w:after="0"/>'))
    return "".join(x)


# ------------------------------------------------------------------ front matter
def front(tpl_body):
    out = [para(run(J.TITLE), "JISEBITitle")]
    runs = []
    for k, (name, _, _) in enumerate(J.AUTHORS, 1):
        if k > 1:
            runs.append(run(", ", b=True))
        runs.append(run(name, b=True))
        runs.append(run(f"{k})", b=True, vert="superscript"))
        if k == J.CORRESPONDING:
            runs.append('<w:r><w:rPr><w:rStyle w:val="FootnoteReference"/><w:b/></w:rPr>'
                        '<w:footnoteReference w:id="1"/></w:r>')
    out.append(para("".join(runs), "JISEBIAuthorName", '<w:ind w:firstLine="0"/><w:jc w:val="left"/>'))
    for a, aff in J.AFFILIATIONS.items():
        members = [k for k, (_, affs, _) in enumerate(J.AUTHORS, 1) if a in affs]
        out.append(para(run("".join(f"{k})" for k in members), vert="superscript", sz=18)
                        + run(aff, sz=18), "JISEBIAuthorAffiliation",
                        '<w:ind w:firstLine="0"/><w:jc w:val="left"/>'))
        mails = [(k, m) for k, (_, affs, m) in enumerate(J.AUTHORS, 1) if affs[0] == a]
        if mails:
            r = []
            for idx, (k, m) in enumerate(mails):
                if idx:
                    r.append(run(", ", sz=16))
                r.append(run(f"{k})", vert="superscript", sz=16) + run(m, sz=16))
            out.append(para("".join(r), "JISEBIAuthorEmail"))
    out.append(para(""))

    # abstract box: the template's own table, with its paragraphs replaced
    tbl = re.search(r"<w:tbl>.*?</w:tbl>", tpl_body, re.S).group(0)
    ps = list(re.finditer(r"<w:p\b[^>]*>.*?</w:p>", tbl, re.S))
    texts = ["".join(re.findall(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>", p.group(0))) for p in ps]
    first = next(i for i, t in enumerate(texts) if t.startswith("Background"))
    new_abs = "".join(para(run(lab + ":", b=True) + run(" ") + inline(ame(txt)), "JISEBIAbstracttext")
                      for lab, txt in J.ABSTRACT)
    kw_i = next(i for i, t in enumerate(texts) if t.startswith("Keywords"))
    new_kw = para(run("Keywords:", b=True, i=True) + run(" " + ", ".join(J.KEYWORDS)),
                  "JISEBIAbstractkeywords")
    instr = next(i for i, t in enumerate(texts) if t.startswith("(Abstract consists"))
    pieces, last = [], 0
    for i, p in enumerate(ps):
        pieces.append(tbl[last:p.start()])
        if i == first:
            pieces.append(new_abs)
        elif first < i <= first + 4 or i == instr:
            pass                                   # template's Objective..Conclusion prompts, instruction
        elif i == kw_i:
            pieces.append(new_kw)
        else:
            pieces.append(p.group(0))
        last = p.end()
    pieces.append(tbl[last:])
    out.append("".join(pieces))
    return "".join(out)


# ------------------------------------------------------------------ body and end matter
def main_body():
    out, eq_n, tbl_n = [], 0, 0
    intro_ids = {id(b) for b in J.INTRO}
    for blk in J.BLOCKS:
        kind = blk[0]
        remap = id(blk) not in intro_ids
        if kind == "h1":
            out.append(para(run(blk[1]), "JISEBIHeading1"))
        elif kind == "h2":
            out.append(para(run(ame(blk[1])), "JISEBIHeading2"))
        elif kind == "p":
            out.append(para(inline(body_text(blk[1], remap))))
        elif kind == "pi":
            out.append(para(run(blk[1] + " ", i=True) + inline(body_text(blk[2]))))
        elif kind == "pb":
            lead, rest = blk[1].split(".", 1)
            out.append(para(run(lead + ".", b=True) + inline(body_text(rest))))
        elif kind == "eq":
            eq_n += 1
            out.append(equation(blk[1], eq_n))
        elif kind == "tbl":
            tbl_n += 1
            out.append(table(blk[1], tbl_n))
        else:
            raise SystemExit(f"unexpected block kind {kind}")
    return "".join(out), eq_n, tbl_n


def end_matter(tpl_body):
    out = [para("")]                                   # spacer after the Conclusions
    for label, txt in J.END_MATTER:
        r = (run(label + ":", b=True) + run(" ")) if label else ""
        out.append(para(r + inline(txt), "Text", '<w:ind w:firstLine="0"/>'))
        out.append(para("", "Text", '<w:ind w:firstLine="0"/>'))
    out.append(para(run("ORCID", b=True) + run(":"), "Text", '<w:ind w:firstLine="0"/>'))
    for name, _, _ in J.AUTHORS:
        out.append(para(run(f"{name}: https://orcid.org/{J.ORCID[name]}"),
                        "Text", '<w:ind w:firstLine="0"/>'))
    out.append(para(run("References"), "JISEBIReferenceheading"))
    missing = [k for k in CITE if k not in J.REFERENCES]
    if missing:
        raise SystemExit(f"cited but not in REFERENCES: {missing}")
    for key, _ in sorted(CITE.items(), key=lambda kv: kv[1]):
        out.append(para(run(J.REFERENCES[key]), "references0"))
    ps = re.findall(r"<w:p\b[^>]*>.*?</w:p>", tpl_body, re.S)
    note = next(p for p in ps if "Publisher" in "".join(re.findall(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>", p)))
    out.append(para(""))
    out.append(note)
    uncited = [k for k in J.REFERENCES if k not in CITE]
    if uncited:
        print("WARNING uncited references:", uncited)
    return "".join(out)


def main():
    J.AFFILIATIONS[3] = "Japan Advanced Institute of Science and Technology (JAIST), Nomi, Japan"
    doc = (TPL / "word" / "document.xml").read_text(encoding="utf-8")
    head = doc[:doc.index("<w:body>") + len("<w:body>")]
    tpl_body = doc[doc.index("<w:body>") + len("<w:body>"):doc.rindex("</w:body>")]
    tail = doc[doc.rindex("</w:body>"):]
    sect = re.findall(r"<w:sectPr\b.*?</w:sectPr>", tpl_body, re.S)[-1]
    sect = re.sub(r"<w:pgSz [^>]*/>", '<w:pgSz w:w="11906" w:h="16838"/>', sect)

    fm = front(tpl_body)
    body, n_eq, n_tbl = main_body()
    em = end_matter(tpl_body)

    if BUILD.exists():
        shutil.rmtree(BUILD)
    shutil.copytree(TPL, BUILD)
    (BUILD / "word" / "document.xml").write_text(head + fm + body + em + sect + tail, encoding="utf-8")

    hdr = BUILD / "word" / "header1.xml"
    h = hdr.read_text(encoding="utf-8")
    new_texts = iter(["Slamin et al.", "", "", "", "", "", " "])
    h = re.sub(r"(<w:t(?:\s[^>]*)?>)(.*?)(</w:t>)",
               lambda m: m.group(1) + next(new_texts, m.group(2)) + m.group(3), h, count=7)
    hdr.write_text(h, encoding="utf-8")

    if OUT.exists():
        OUT.unlink()
    files = [p for p in sorted(BUILD.rglob("*")) if p.is_file()]
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(BUILD / "[Content_Types].xml", "[Content_Types].xml")
        for p in files:
            if p.name != "[Content_Types].xml":
                z.write(p, str(p.relative_to(BUILD)).replace("\\", "/"))

    # checks on the generated text
    plain = re.sub(r"<[^>]+>", " ", fm + body)
    left = sorted({w for w in BRITISH.findall(plain) if w.lower() not in BRIT_OK})
    print(f"wrote {OUT.name}: {n_tbl} tables, {n_eq} equations, {len(CITE)} references")
    print("British spellings left in body:", left or "none")


if __name__ == "__main__":
    main()
