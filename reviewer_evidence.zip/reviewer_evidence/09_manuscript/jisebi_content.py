"""Content of the JISEBI manuscript.

Verified text blocks are reused *by reference* from ../soic/soic_content.py (the audited JOIV
content with seven unverifiable reference details removed), so every number is identical.
New text is written only where JISEBI's rules require it:
  - a structured abstract (Background/Objective/Methods/Results/Conclusion, 150-300 words);
  - a title and introduction without the case study (JISEBI: the case study is a data source,
    described in Methods, not in the title or introduction);
  - an introduction that states the research gap with recent citations and the objectives;
  - IMRaD with Results and Discussion separated: interpretive sentences move to Discussion;
  - at most two heading levels and no bullet lists;
  - the mandatory end statements.
Text marked with double angle quotes is a placeholder the authors must complete; the builder
highlights it in yellow.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "soic"))
import soic_content as S  # noqa: E402

B = S.BLOCKS
REFERENCES = S.REFERENCES


def text(i):
    """Text of verified block i (paragraph or run-in heading body)."""
    blk = B[i]
    return blk[2] if blk[0] == "h3" else blk[1]


def cut(i, sentence):
    """Verified block i with one sentence removed (asserts the sentence is there)."""
    t = text(i)
    assert sentence in t, (i, sentence[:50])
    return t.replace(" " + sentence, "").replace(sentence, "").strip()


TITLE = ("Admissibility Gates for Relational Graph Neural Network Evaluation on News-Derived "
         "Temporal Knowledge Graphs")
TITLE_PREVIOUS = ("Admissibility Gates for Relational Graph Neural Network Evaluation on a "
                  "News-Derived Temporal Knowledge Graph of East Java Food-System Disruptions")

ABSTRACT = [
    ("Background", "News reports are the main record of food-system disruptions and of the "
     "government responses to them, and temporal knowledge graphs (TKGs) built from news are "
     "increasingly used for graph learning. How such a benchmark is constructed can, however, make "
     "a model comparison uninterpretable in ways that no trained model’s score reveals."),
    ("Objective", "To define construction-time admissibility gates that decide whether a model "
     "comparison on a news-derived TKG is interpretable, and to test them on a new resource with a "
     "relational graph neural network."),
    ("Methods", "An ontology-first TKG was built from 1,504,980 Indonesian news articles: a "
     "SHACL-conforming 300-article pilot extended to 2,235 articles, 1,107 events and a typed "
     "learning view of 3,398 nodes and 6,489 edges. Three gates—task non-degeneracy, benchmark "
     "integrity and statistical power—were applied to five candidate tasks, and a relational "
     "graph convolutional network (R-GCN) was compared with rule-based baselines using filtered "
     "ranking, a paired bootstrap and a sign-flip permutation test."),
    ("Results", "All five tasks failed at least one gate. A language model shown only anonymized "
     "symbols still ranked the true target first in eight of ten queries. A cross-document task "
     "rebuilt from 65 judged positives passed the integrity gate when competitors were counted over "
     "news reports (29% strictly hardest, median 3 competitors) but failed it when they were counted "
     "over distinct incidents (52%, median 0). A same-district, most-recent heuristic reached MRR "
     "0.921 against 0.259 for the R-GCN (d_{z} = −1.75)."),
    ("Conclusion", "A benchmark gate is only as sound as the unit it counts. News-derived "
     "benchmarks should report that unit and pass the gates before model comparisons are read; "
     "future work should build tasks with at least 215 positives and negatives that the candidate "
     "blocking rule does not determine."),
]
KEYWORDS = ["Admissibility Gates", "Benchmark Integrity", "Graph Neural Network",
            "Link Prediction", "Statistical Power", "Temporal Knowledge Graph"]

INTRO = [
 ("p", "Disruptions to food supply—crop failure, floods, animal disease outbreaks, "
       "distribution breakdowns—and the government responses that follow are documented mainly "
       "in news reporting, and food-security early warning leans on that reporting and on the "
       "analyses built from it [[cooper2020textmining]], [[krishnamurthy2020famine]], "
       "[[backer2021fews]]. Temporal knowledge graphs (TKGs) turn such reporting into timestamped "
       "relations between events, actors, places and policies, and are a natural substrate for "
       "graph learning [[hogan2021kg]], [[hao2025survey]]. The standard news-derived resources, "
       "ICEWS [[boschee2015icews]] and GDELT [[leetaru2013gdelt]], compress each fact into a single "
       "timestamp, discarding the distinction between when an event occurred and when it was "
       "reported, on which any no-look-ahead evaluation depends, and they present extraction output "
       "as fact, without the evidence span, extractor identity or confidence needed to judge label "
       "quality."),
 ("p", "Recent work has shown that reported gains on temporal graph benchmarks are often artifacts "
       "of evaluation design. Memorization and recency heuristics outperform temporal graph networks "
       "under random negatives [[poursafaei2022better]], simple sampling produces saturated "
       "predictions [[daniluk2023saturation]], and standardized benchmarks now rank against harder "
       "negative regimes [[huang2023tgb]], [[gastinger2024tgb2]]. Language models forecast temporal "
       "knowledge graphs competitively even when entities are replaced by arbitrary symbols "
       "[[lee2023icl]], [[liao2024gentkg]], which suggests that a score can reflect regularities of "
       "the candidate set rather than knowledge of the events. These studies diagnose saturation at "
       "evaluation time, on existing datasets. What is missing is a construction-time test: a way to "
       "decide, while a benchmark is being built from news, whether it can support an interpretable "
       "model comparison at all—and a check of whether such a test is itself sensitive to how the "
       "many news reports of one event are counted."),
 ("p", "This study addresses that gap. Its objective is to define admissibility gates that must "
       "pass before a model comparison on a news-derived TKG is interpreted, and to apply them to a "
       "new resource and a relational graph neural network. The paper makes four contributions. "
       "First, a provenance-aware TKG ontology that separates event valid time, report time and "
       "corpus observation time, with a validated pilot and an expanded corpus. Second, an "
       "evaluation protocol for a relational graph convolutional network (R-GCN) with target-edge "
       "masking, incident-level candidate sets and a paired significance test sized by an explicit "
       "power analysis. Third, three admissibility gates—task non-degeneracy, benchmark integrity "
       "and statistical power—whose failures are shown to be model-agnostic. Fourth, a rebuilt "
       "cross-document task that passes the integrity gate when competitors are counted as news "
       "reports and fails it when they are counted as incidents, with ranking results that confirm "
       "the corrected verdict. The remainder of the paper reviews related work (Section II), "
       "describes the data source and methods (Section III), reports the results (Section IV), "
       "discusses them (Section V) and concludes (Section VI)."),
]

CASE_STUDY = ("The case study, used here as the data source, is the news reporting of food-system "
              "disruptions and government responses in East Java province, Indonesia. ")

# sentences moved from Results to Discussion (JISEBI: results without interpretation)
MV_ICL = ("The signal is symbolic and temporal regularity in the candidate set, so admissibility is "
          "a property of the data and cannot be established by observing that some model does or "
          "does not succeed.")
MV_ENS = ("The disagreement encodes the annotation convention rather than the evidence, which is a "
          "caution against treating ensemble entropy as calibrated uncertainty.")
WHY = text(78)
WHY_DATA_START = "Every positive lies in the response’s district within 180 days"
WHY_INTERP_START = "“Same district, most recent” thus restates"
assert WHY_DATA_START in WHY and WHY_INTERP_START in WHY
WHY_DATA = WHY[WHY.index(WHY_DATA_START):WHY.index(WHY_INTERP_START)].strip()
WHY_INTERP = WHY[WHY.index(WHY_INTERP_START):].strip()
STATUS = text(84)
STATUS_FIRST = ("The resource, pipeline, models and gates are complete and reproducible, but no task "
                "yet clears all three gates (Table VII).")
assert STATUS.startswith(STATUS_FIRST)
STATUS_REST = STATUS[len(STATUS_FIRST):].strip()

EQ = [
    "H^{(l+1)} = ReLU(H^{(l)}W_{0}^{(l)} + ∑_{r∈R}A_{r}H^{(l)}W_{r}^{(l)}),    H^{(0)} = X",
    "N_{r}^{ρ}(v, t) = {u : (u, v) ∈ E_{r}, ρ_{(u,v)} ≤ t}",
    "Pr[y_{e} = argmax_{y} #{e′ : σ(e′) = σ(e), y_{e′} = y}] → 1",
    "h(r, d) = 4·I[c_{r} = c_{d}] + 2·I[c_{r} ~ c_{d}] + 1.5·I[ℓ_{r} = ℓ_{d}] "
    "+ 0.5·I[s_{r} = s_{d}] + γ(r, d)",
    "Pr[h(r, d^{+}) > max_{d^{−}}h(r, d^{−})] < 0.80,    "
    "med|{d^{−} : h(r, d^{−}) ≥ h(r, d^{+})}| ≥ 1",
]


def lead(i, label):
    """Run-in italic lead-in replacing a level-3 heading (JISEBI allows two heading levels)."""
    return ("pi", label, text(i))


BLOCKS = [("h1", "Introduction"), *INTRO,

 ("h1", "Literature Review"),
 ("h2", "Temporal Knowledge Graphs and Graph Neural Networks"), B[9],
 ("h2", "Event Extraction from News"), B[10],
 ("h2", "Evaluation of Temporal Graph Benchmarks"), B[12],

 ("h1", "Methods"),
 ("h2", "Data Source and Pilot Annotation"), ("p", CASE_STUDY + text(15)), B[16],
 ("h2", "Density-Targeted Expansion"), B[18], B[19],
 ("h2", "Ontology and Pipeline"), B[21], B[22], B[23], B[24], B[25],
 ("h2", "Modeling View"), B[27],
 ("h2", "Relational Graph Convolution"), B[29], ("eq", EQ[0]), B[31],
 ("h2", "Report-Time Constrained Neighborhoods"), B[33], ("eq", EQ[1]), B[35],
 ("h2", "Ablation Design and Model Capacity"), B[37], B[38], B[39], B[40],
 ("h2", "Training-Free In-Context Arm"), B[42],
 ("h2", "Paired Significance Protocol"), B[44],
 ("h2", "Admissibility Gates"), B[46],
 lead(47, "Layer 0, task non-degeneracy."), ("eq", EQ[2]), B[49],
 lead(50, "Layer 1, benchmark integrity."), ("eq", EQ[3]), B[52], ("eq", EQ[4]), B[54],
 lead(55, "Layer 2, statistical power."), B[56],
 ("h2", "Cross-Document Supervision"), B[58], B[59], B[60],

 ("h1", "Results"),
 ("h2", "Construction Diagnostics"), B[63], ("p", cut(64, MV_ICL)), B[65], B[66],
 ("p", cut(67, MV_ENS)),
 ("h2", "Effect on the Gates"), B[69], B[70], B[71],
 ("h2", "Ranking Results"), B[73], B[74], B[75], B[76], B[77],
 ("p", "Three properties of the positives bear on these scores. " + WHY_DATA),
 ("h2", "Summary of Candidate Tasks"),
 ("p", "No task clears all three gates. Table VII summarizes the layer each candidate task fails "
       "and the diagnosis behind it."), B[85],

 ("h1", "Discussion"),
 ("h2", "Interpretation of the Ranking Results"),
 ("p", "The ranking results are the Layer-1 failure seen from the score side. " + WHY_INTERP),
 ("p", "The in-context arm leads to the same conclusion from the model side. " + MV_ICL + " The "
       "coreference ensemble adds a caution about uncertainty estimates: " + MV_ENS[0].lower() + MV_ENS[1:]),
 ("h2", "Comparison with Previous Studies"), B[80], B[81],
 ("h2", "Implications for Food-System Monitoring"), B[82],
 ("h2", "Limitations"), ("p", STATUS_REST), B[86],

 ("h1", "Conclusions"), B[88], B[89], B[90],
]

END_MATTER = [
    ("Author Contributions", "Slamin: Conceptualization, Methodology, Investigation, Supervision, "
     "Project Administration (project leader). Rizky Alfanio Atmoko: Conceptualization, "
     "Methodology, Investigation, Writing - Original Draft. Yuqing Lin: Conceptualization, "
     "Methodology, Supervision. Antonius Cahya Prihandoko: Supervision, Validation, Formal Analysis "
     "(theoretical foundations). Qurrota A’yuni Ar Ruhimat: Funding Acquisition, Data Curation, "
     "Investigation. Annisa Fitri Maghfiroh Harvyanti: Data Curation, Investigation, Writing - "
     "Review & Editing. Muhammad Ariful Furqon: Methodology. Bayu Taruna Widjaja Putra: Validation "
     "(agricultural domain expertise). Roslan Hasni: Supervision, Formal Analysis (theoretical "
     "foundations)."),
    (None, "All authors have read and agreed to the published version of the manuscript."),
    ("Funding", "«This work was supported by Universitas Jember under an international "
     "collaboration scheme with Universiti Malaysia Terengganu, Malaysia, grant number <xxx>. "
     "[Confirm that this scheme funded this study, and add the grant number.]»"),
    ("Conflicts of Interest", "«The authors declare no conflict of interest.»"),
    ("Data Availability", "The ontology, annotation outputs, knowledge-graph exports, evaluation "
     "scripts and result files that support the findings are available from the corresponding "
     "author on reasonable request «[or: are deposited at <repository URL>]». The source "
     "news articles are copyrighted by their publishers and cannot be redistributed; article "
     "identifiers and URLs are provided instead."),
    ("Informed Consent", "There were no human subjects."),
    ("Institutional Review Board Statement", "Not applicable."),
    ("Animal Subjects", "There were no animal subjects."),
]

AUTHORS = [  # (name, affiliation groups, e-mail) in the AEGIS order supplied by the user
    ("Slamin", [1], "slamin@unej.ac.id"),
    ("Rizky Alfanio Atmoko", [1], "rizkyaatmoko@unej.ac.id"),
    ("Yuqing Lin", [2], "yuqing.lin@newcastle.edu.au"),
    ("Antonius Cahya Prihandoko", [1], "antoniuscp.ilkom@unej.ac.id"),
    ("Qurrota A’yuni Ar Ruhimat", [1], "qurrotaaar@unej.ac.id"),
    ("Annisa Fitri Maghfiroh Harvyanti", [1], "annisafmh@unej.ac.id"),
    ("Muhammad Ariful Furqon", [1, 3], "ariful.furqon@unej.ac.id"),
    ("Bayu Taruna Widjaja Putra", [4], "bayu@unej.ac.id"),
    ("Roslan Hasni", [5], "hroslan@umt.edu.my"),
]
ORCID = {
    "Slamin": "0000-0002-1280-8037",
    "Rizky Alfanio Atmoko": "0009-0006-3050-8579",
    "Yuqing Lin": "0000-0002-6693-0433",
    "Antonius Cahya Prihandoko": "0000-0001-7112-5458",
    "Qurrota A’yuni Ar Ruhimat": "0009-0009-3822-4433",
    "Annisa Fitri Maghfiroh Harvyanti": "0009-0008-4524-7281",
    "Muhammad Ariful Furqon": "0000-0002-1031-3567",
    "Bayu Taruna Widjaja Putra": "0000-0001-8944-7957",
    "Roslan Hasni": "0000-0003-3695-2145",
}
CORRESPONDING = 2          # 1-based position in AUTHORS
AFFILIATIONS = {
    1: "Department of Informatics, Faculty of Computer Science, University of Jember, Jember, Indonesia",
    2: "School of Information and Physical Sciences, University of Newcastle, Newcastle, Australia",
    3: "Japan Advanced Institute of Science and Technology, Nomi, Japan",
    4: "Department of Agricultural Engineering, Faculty of Agricultural Technology, University of "
       "Jember, Jember, Indonesia",
    5: "Faculty of Computer Science and Mathematics, Universiti Malaysia Terengganu, Kuala Nerus, "
       "Malaysia",
}

# Cross-references of the reused blocks, remapped to JISEBI's auto-numbered sections
SECTION_MAP = {"Section III.A": "Section IV.A", "Section III.B": "Section IV.B",
               "Section I.B": "Section II.C", "Section III": "Section IV"}
